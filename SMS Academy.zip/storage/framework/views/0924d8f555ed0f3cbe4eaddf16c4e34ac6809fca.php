
<li class="nav-item">
    <a href="<?php echo e(route('books.index')); ?>" class="nav-link <?php echo e(Route::is('books.index') ? 'active' : ''); ?>">
        <i class="icon-books"></i> <span><?php echo e(__('Library Dashboard')); ?></span>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('books.circulations')); ?>" class="nav-link <?php echo e(Route::is('books.circulations') ? 'active' : ''); ?>">
        <i class="icon-sync"></i> <span><?php echo e(__('Issue & Return')); ?></span>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('book_requests.index')); ?>" class="nav-link <?php echo e(Route::is('book_requests.index') ? 'active' : ''); ?>">
        <i class="icon-list3"></i> <span><?php echo e(__('Book Requests')); ?></span>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('books.categories')); ?>" class="nav-link <?php echo e(Route::is('books.categories') ? 'active' : ''); ?>">
        <i class="icon-folder-open"></i> <span><?php echo e(__('Book Categories')); ?></span>
    </a>
</li><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/pages/librarian/menu.blade.php ENDPATH**/ ?>