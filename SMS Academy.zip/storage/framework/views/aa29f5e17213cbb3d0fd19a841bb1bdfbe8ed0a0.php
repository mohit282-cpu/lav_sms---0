
<li class="nav-item">
    <a href="<?php echo e(route('settings')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['settings',]) ? 'active' : ''); ?>"><i class="icon-gear"></i> <span><?php echo e(__('Settings')); ?></span></a>
</li>


<li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['pins.create', 'pins.index']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
    <a href="#" class="nav-link"><i class="icon-lock2"></i> <span> <?php echo e(__('Pins')); ?></span></a>

    <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Manage Pins')); ?>">
        
            <li class="nav-item">
                <a href="<?php echo e(route('pins.create')); ?>"
                   class="nav-link <?php echo e((Route::is('pins.create')) ? 'active' : ''); ?>"><?php echo e(__('Generate Pins')); ?></a>
            </li>

        
        <li class="nav-item">
            <a href="<?php echo e(route('pins.index')); ?>"
               class="nav-link <?php echo e((Route::is('pins.index')) ? 'active' : ''); ?>"><?php echo e(__('View Pins')); ?></a>
        </li>
    </ul>
</li><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/pages/super_admin/menu.blade.php ENDPATH**/ ?>