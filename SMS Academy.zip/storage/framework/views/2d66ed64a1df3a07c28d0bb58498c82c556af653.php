<?php $__env->startSection('page_title', __('Edit Academic Year (BS)') . ' - ' . $ay->name); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('Edit Nepali Academic Session (BS)')); ?> - <?php echo e($ay->name); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <form method="post" action="<?php echo e(route('academic_years.update', $ay->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Session Name')); ?>: <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="name" value="<?php echo e(old('name', $ay->name)); ?>" required type="text" class="form-control" placeholder="e.g. 2083/84 BS">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Academic Year (BS)')); ?>: <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="year_bs" value="<?php echo e(old('year_bs', $ay->year_bs)); ?>" required type="number" min="2000" max="2090" class="form-control" placeholder="2083">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Start Date (BS)')); ?>: <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="start_date_bs" value="<?php echo e(old('start_date_bs', $ay->start_date_bs)); ?>" required type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                <span class="form-text text-muted"><?php echo e(__('First day of Baishakh')); ?> (<?php echo e($ay->start_date ? $ay->start_date->format('Y-m-d') : ''); ?> AD)</span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('End Date (BS)')); ?>: <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="end_date_bs" value="<?php echo e(old('end_date_bs', $ay->end_date_bs)); ?>" required type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                <span class="form-text text-muted"><?php echo e(__('Last day of Chaitra')); ?> (<?php echo e($ay->end_date ? $ay->end_date->format('Y-m-d') : ''); ?> AD)</span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Description')); ?>:</label>
                            <div class="col-lg-9">
                                <textarea name="description" class="form-control" rows="3" placeholder="<?php echo e(__('Optional notes on session')); ?>"><?php echo e(old('description', $ay->description)); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Set as Active Session')); ?>:</label>
                            <div class="col-lg-9">
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="checkbox" name="is_active" value="1" class="form-check-input-styled" <?php echo e(old('is_active', $ay->is_active) ? 'checked' : ''); ?> data-fouc>
                                        <?php echo e(__('Make this session active for student admissions, marks, and fees')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="text-right">
                            <a href="<?php echo e(route('academic_years.index')); ?>" class="btn btn-secondary mr-2"><?php echo e(__('Cancel')); ?></a>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Update Session')); ?> <i class="icon-paperplane ml-2"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/pages/support_team/academic_years/edit.blade.php ENDPATH**/ ?>