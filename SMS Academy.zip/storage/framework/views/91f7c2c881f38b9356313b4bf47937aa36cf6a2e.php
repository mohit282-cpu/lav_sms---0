<?php $__env->startSection('page_title', __('My Library Account: Books & Requests')); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        
        <div class="col-md-7">
            <div class="card">
                <div class="card-header header-elements-inline bg-light">
                    <h6 class="card-title font-weight-semibold text-primary">
                        <i class="icon-reading mr-2"></i><?php echo e(__('Currently Borrowed Books')); ?> (<?php echo e(count($my_loans)); ?>)
                    </h6>
                    <div class="header-elements">
                        <a href="<?php echo e(route('books.catalogue')); ?>" class="btn btn-sm btn-outline-primary font-weight-bold">
                            <i class="icon-search4 mr-1"></i> <?php echo e(__('Browse Catalogue')); ?>

                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(count($my_loans) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(__('Book Title')); ?></th>
                                    <th><?php echo e(__('Issue Date (BS)')); ?></th>
                                    <th><?php echo e(__('Due Date (BS)')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $my_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <div class="font-weight-semibold">
                                                <a href="<?php echo e(route('books.show', $loan->book_id)); ?>"><?php echo e($loan->book ? $loan->book->name : '-'); ?></a>
                                            </div>
                                            <?php if($loan->book && $loan->book->author): ?>
                                                <div class="text-muted font-size-xs"><?php echo e($loan->book->author); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($loan->issue_date_bs ?: $loan->issue_date); ?></td>
                                        <td>
                                            <span class="<?php echo e($loan->is_overdue ? 'text-danger font-weight-bold' : ''); ?>">
                                                <?php echo e($loan->due_date_bs ?: $loan->due_date); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($loan->is_overdue): ?>
                                                <span class="badge badge-danger font-weight-bold"><?php echo e(__('Overdue')); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-success"><?php echo e(__('Borrowed')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="icon-book2 icon-2x mb-2 text-muted"></i>
                            <p class="mb-0"><?php echo e(__('You currently have no books on loan.')); ?></p>
                            <a href="<?php echo e(route('books.catalogue')); ?>" class="btn btn-sm btn-primary mt-2">
                                <?php echo e(__('Explore Library Catalogue')); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-md-5">
            <div class="card">
                <div class="card-header header-elements-inline bg-light">
                    <h6 class="card-title font-weight-semibold text-warning">
                        <i class="icon-hour-glass2 mr-2"></i><?php echo e(__('My Book Requests')); ?> (<?php echo e(count($my_requests)); ?>)
                    </h6>
                </div>

                <div class="card-body">
                    <?php if(count($my_requests) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(__('Book Title')); ?></th>
                                    <th><?php echo e(__('Date')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th class="text-center"><?php echo e(__('Action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $my_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <span class="font-weight-semibold"><?php echo e($req->book ? $req->book->name : '-'); ?></span>
                                        </td>
                                        <td><?php echo e($req->request_date_bs ?: $req->created_at->format('Y-m-d')); ?></td>
                                        <td>
                                            <?php if($req->status == 'pending'): ?>
                                                <span class="badge badge-warning"><?php echo e(__('Pending')); ?></span>
                                            <?php elseif($req->status == 'approved'): ?>
                                                <span class="badge badge-success"><?php echo e(__('Approved')); ?></span>
                                            <?php elseif($req->status == 'issued'): ?>
                                                <span class="badge badge-primary"><?php echo e(__('Issued')); ?></span>
                                            <?php elseif($req->status == 'rejected'): ?>
                                                <span class="badge badge-danger"><?php echo e(__('Rejected')); ?></span>
                                            <?php elseif($req->status == 'cancelled'): ?>
                                                <span class="badge badge-secondary"><?php echo e(__('Cancelled')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($req->status == 'pending'): ?>
                                                <form method="post" action="<?php echo e(route('book_requests.cancel', $req->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-xs btn-outline-danger" onclick="return confirm('<?php echo e(__('Cancel this request?')); ?>')">
                                                        <i class="icon-cross2"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <p class="mb-0"><?php echo e(__('You have not submitted any book requests.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\my_requests.blade.php ENDPATH**/ ?>