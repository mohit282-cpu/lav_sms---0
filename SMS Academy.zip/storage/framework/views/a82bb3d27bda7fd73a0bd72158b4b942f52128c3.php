<?php $__env->startSection('page_title', __('My Timetable')); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h6 class="card-title font-weight-bold"><i class="icon-calendar mr-2"></i><?php echo e(__('Class Timetable')); ?></h6>
        <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body text-center py-5">
        <i class="icon-calendar2 icon-3x text-muted mb-3 d-block"></i>
        <h5 class="text-muted"><?php echo e(__('No timetable has been published for your class yet.')); ?></h5>
        <p class="text-muted"><?php echo e(__('Please check back later or contact your class teacher / school administrator.')); ?></p>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\timetables\my_timetable.blade.php ENDPATH**/ ?>