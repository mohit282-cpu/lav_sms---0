
<?php $__env->startSection('page_title', 'My Children'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">My Children</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <table class="table datatable-button-html5-columns">
                <thead>
                <tr>
                    <th>S/N</th>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>ADM_No</th>
                    <th>Section</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><img class="rounded-circle" style="height: 40px; width: 40px;" src="<?php echo e($s->user->photo); ?>" alt="photo"></td>
                        <td><?php echo e($s->user->name); ?></td>
                        <td><?php echo e($s->adm_no); ?></td>
                        <td><?php echo e($s->my_class->name.' '.$s->section->name); ?></td>
                        <td><?php echo e($s->user->email); ?></td>
                        <td class="text-center">
                            <div class="list-icons">
                                <div class="dropdown">
                                    <a href="#" class="list-icons-item" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-left">
                                        <a href="<?php echo e(route('students.show', Qs::hash($s->id))); ?>" class="dropdown-item"><i class="icon-eye"></i> <?php echo e(__('View Profile')); ?></a>
                                        <a target="_blank" href="<?php echo e(route('marks.year_selector', Qs::hash($s->user->id))); ?>" class="dropdown-item"><i class="icon-check"></i> <?php echo e(__('Marksheet')); ?></a>
                                        <a href="<?php echo e(route('payments.invoice', [Qs::hash($s->user->id), Qs::getCurrentSession()])); ?>" class="dropdown-item"><i class="icon-cash"></i> <?php echo e(__('Fees & Payments')); ?></a>
                                        <a href="<?php echo e(route('tt.student_timetable', Qs::hash($s->user->id))); ?>" class="dropdown-item"><i class="icon-calendar"></i> <?php echo e(__('Timetable')); ?></a>
                                        <a href="<?php echo e(route('attendance.student_history', $s->user_id)); ?>" class="dropdown-item"><i class="icon-alarm"></i> <?php echo e(__('Attendance')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\parent\children.blade.php ENDPATH**/ ?>