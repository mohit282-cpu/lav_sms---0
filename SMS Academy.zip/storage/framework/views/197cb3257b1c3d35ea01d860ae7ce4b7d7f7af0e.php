<?php $__env->startSection('page_title', __('Academic Years (BS)')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('Manage Nepali Academic Sessions (BS)')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#all-academic-years" class="nav-link active" data-toggle="tab"><?php echo e(__('All Academic Years')); ?></a></li>
                <li class="nav-item"><a href="#new-academic-year" class="nav-link" data-toggle="tab"><i class="icon-plus2"></i> <?php echo e(__('Create Academic Year')); ?></a></li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade show active" id="all-academic-years">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Session Name')); ?></th>
                            <th><?php echo e(__('Year (BS)')); ?></th>
                            <th><?php echo e(__('Start Date')); ?></th>
                            <th><?php echo e(__('End Date')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $academic_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-semibold"><?php echo e($ay->name); ?></td>
                                <td><?php echo e(App\Helpers\NepaliHelper::formatNumber($ay->year_bs)); ?> BS</td>
                                <td><?php echo e($ay->start_date_bs); ?> BS <span class="text-muted">(<?php echo e($ay->start_date ? $ay->start_date->format('Y-m-d') : ''); ?>)</span></td>
                                <td><?php echo e($ay->end_date_bs); ?> BS <span class="text-muted">(<?php echo e($ay->end_date ? $ay->end_date->format('Y-m-d') : ''); ?>)</span></td>
                                <td>
                                    <?php if($ay->is_active): ?>
                                        <span class="badge badge-success p-2"><?php echo e(__('Active Session')); ?></span>
                                    <?php elseif($ay->is_closed): ?>
                                        <span class="badge badge-secondary p-2"><?php echo e(__('Closed / Archived')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-info p-2"><?php echo e(__('Inactive')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="list-icons">
                                        <div class="dropdown">
                                            <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                <i class="icon-menu9"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-left">
                                                <a href="<?php echo e(route('academic_years.edit', $ay->id)); ?>" class="dropdown-item"><i class="icon-pencil"></i> <?php echo e(__('Edit')); ?></a>
                                                <?php if(!$ay->is_active): ?>
                                                    <a href="#" onclick="event.preventDefault(); document.getElementById('activate-form-<?php echo e($ay->id); ?>').submit();" class="dropdown-item text-success"><i class="icon-check"></i> <?php echo e(__('Set as Active Session')); ?></a>
                                                    <form id="activate-form-<?php echo e($ay->id); ?>" method="post" action="<?php echo e(route('academic_years.activate', $ay->id)); ?>" style="display: none;"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?></form>
                                                <?php endif; ?>
                                                <?php if($ay->is_closed): ?>
                                                    <a href="#" onclick="event.preventDefault(); document.getElementById('reopen-form-<?php echo e($ay->id); ?>').submit();" class="dropdown-item text-info"><i class="icon-unlocked2"></i> <?php echo e(__('Reopen Session')); ?></a>
                                                    <form id="reopen-form-<?php echo e($ay->id); ?>" method="post" action="<?php echo e(route('academic_years.reopen', $ay->id)); ?>" style="display: none;"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?></form>
                                                <?php else: ?>
                                                    <a href="#" onclick="event.preventDefault(); document.getElementById('close-form-<?php echo e($ay->id); ?>').submit();" class="dropdown-item text-warning"><i class="icon-lock"></i> <?php echo e(__('Close / Archive Session')); ?></a>
                                                    <form id="close-form-<?php echo e($ay->id); ?>" method="post" action="<?php echo e(route('academic_years.close', $ay->id)); ?>" style="display: none;"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?></form>
                                                <?php endif; ?>
                                                <?php if(!$ay->is_active): ?>
                                                    <a id="<?php echo e($ay->id); ?>" onclick="confirmDelete(this.id)" href="#" class="dropdown-item text-danger"><i class="icon-trash"></i> <?php echo e(__('Delete')); ?></a>
                                                    <form method="post" id="item-delete-<?php echo e($ay->id); ?>" action="<?php echo e(route('academic_years.destroy', $ay->id)); ?>" style="display: none;"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?></form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="new-academic-year">
                    <div class="row">
                        <div class="col-md-8">
                            <form method="post" action="<?php echo e(route('academic_years.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Session Name')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="name" value="<?php echo e(old('name', '2083/84 BS')); ?>" required type="text" class="form-control" placeholder="e.g. 2083/84 BS">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Academic Year (BS)')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="year_bs" value="<?php echo e(old('year_bs', 2083)); ?>" required type="number" min="2000" max="2090" class="form-control" placeholder="2083">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Start Date (BS)')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="start_date_bs" value="<?php echo e(old('start_date_bs', '2083-01-01')); ?>" required type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                        <span class="form-text text-muted"><?php echo e(__('First day of Baishakh')); ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('End Date (BS)')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="end_date_bs" value="<?php echo e(old('end_date_bs', '2083-12-30')); ?>" required type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                        <span class="form-text text-muted"><?php echo e(__('Last day of Chaitra')); ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Description')); ?>:</label>
                                    <div class="col-lg-9">
                                        <textarea name="description" class="form-control" rows="3" placeholder="<?php echo e(__('Optional notes on session')); ?>"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Set as Active Session')); ?>:</label>
                                    <div class="col-lg-9">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="is_active" value="1" class="form-check-input-styled" checked data-fouc>
                                                <?php echo e(__('Make this session active for student admissions, marks, and fees')); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Create Session')); ?> <i class="icon-paperplane ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\academic_years\index.blade.php ENDPATH**/ ?>