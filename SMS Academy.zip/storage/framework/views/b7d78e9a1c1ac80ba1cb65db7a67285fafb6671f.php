<?php $__env->startSection('page_title', __('Edit Notice')); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h6 class="card-title font-weight-bold"><?php echo e(__('Edit School Notice')); ?></h6>
        <div class="header-elements">
            <a href="<?php echo e(route('notices.index')); ?>" class="btn btn-outline-secondary btn-sm"><i class="icon-arrow-left52 mr-1"></i><?php echo e(__('Back to Notices')); ?></a>
        </div>
    </div>

    <div class="card-body">
        <form method="post" action="<?php echo e(route('notices.update', $notice->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="form-group">
                        <label class="font-weight-semibold"><?php echo e(__('Notice Title')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" required value="<?php echo e(old('title', $notice->title)); ?>">
                    </div>
                    <div class="form-group">
                        <label class="font-weight-semibold"><?php echo e(__('Content')); ?> <span class="text-danger">*</span></label>
                        <textarea name="content" rows="10" class="form-control" required><?php echo e(old('content', $notice->content)); ?></textarea>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="font-weight-semibold"><?php echo e(__('Notice Date (BS)')); ?></label>
                        <input type="text" name="notice_date_bs" class="form-control nepali-datepicker" value="<?php echo e(old('notice_date_bs', $notice->notice_date_bs)); ?>" placeholder="YYYY-MM-DD">
                    </div>
                    <div class="form-group">
                        <label class="font-weight-semibold"><?php echo e(__('Expiry Date (BS)')); ?></label>
                        <input type="text" name="expiry_date_bs" class="form-control nepali-datepicker" value="<?php echo e(old('expiry_date_bs', $notice->expiry_date_bs)); ?>" placeholder="YYYY-MM-DD">
                    </div>
                    <div class="form-group">
                        <label class="font-weight-semibold"><?php echo e(__('Target Role Visibility')); ?></label>
                        <select name="role_visibility" class="form-control select">
                            <option <?php echo e($notice->role_visibility == 'all' ? 'selected' : ''); ?> value="all"><?php echo e(__('All Users')); ?></option>
                            <option <?php echo e($notice->role_visibility == 'teacher' ? 'selected' : ''); ?> value="teacher"><?php echo e(__('Teachers Only')); ?></option>
                            <option <?php echo e($notice->role_visibility == 'student' ? 'selected' : ''); ?> value="student"><?php echo e(__('Students Only')); ?></option>
                            <option <?php echo e($notice->role_visibility == 'parent' ? 'selected' : ''); ?> value="parent"><?php echo e(__('Parents Only')); ?></option>
                            <option <?php echo e($notice->role_visibility == 'accountant' ? 'selected' : ''); ?> value="accountant"><?php echo e(__('Accountants Only')); ?></option>
                            <option <?php echo e($notice->role_visibility == 'librarian' ? 'selected' : ''); ?> value="librarian"><?php echo e(__('Librarians Only')); ?></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="font-weight-semibold"><?php echo e(__('Specific Class (Optional)')); ?></label>
                        <select name="my_class_id" class="form-control select">
                            <option value=""><?php echo e(__('All Classes')); ?></option>
                            <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($notice->my_class_id == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="form-check form-check-switchery">
                            <label class="form-check-label font-weight-semibold">
                                <input type="checkbox" name="is_published" value="1" class="form-check-input-switchery" <?php echo e($notice->is_published ? 'checked' : ''); ?>>
                                <?php echo e(__('Published')); ?>

                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block"><i class="icon-sync mr-2"></i><?php echo e(__('Update Notice')); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\notices\edit.blade.php ENDPATH**/ ?>