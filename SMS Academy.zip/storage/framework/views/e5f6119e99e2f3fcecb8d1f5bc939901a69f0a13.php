<?php $__env->startSection('page_title', __('Daily Staff Attendance (BS)')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('Daily Staff Attendance (Bikram Sambat)')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <form method="get" action="<?php echo e(route('staff_attendance.index')); ?>">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-weight-bold"><?php echo e(__('Attendance Date (BS)')); ?>: <span class="text-danger">*</span></label>
                            <input type="text" name="attendance_date_bs" value="<?php echo e($selected_date); ?>" required class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                            <?php if(isset($date_info) && $date_info['ad_date']): ?>
                                <span class="form-text text-muted"><?php echo e($date_info['ad_date']); ?> AD</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3 pt-md-4">
                        <button type="submit" class="btn btn-primary btn-block"><i class="icon-filter3 mr-1"></i> <?php echo e(__('Load Staff List')); ?></button>
                    </div>
                    <div class="col-md-3 pt-md-4">
                        <a href="<?php echo e(route('staff_attendance.monthly')); ?>" class="btn btn-outline-info btn-block"><i class="icon-calendar52 mr-1"></i> <?php echo e(__('Staff Monthly Summary')); ?></a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if(isset($date_info) && $date_info['warning']): ?>
        <div class="alert alert-<?php echo e($date_info['is_holiday'] ? 'danger' : 'warning'); ?> border-0 alert-dismissible">
            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
            <span class="font-weight-semibold"><i class="icon-warning22 mr-1"></i> <?php echo e($date_info['warning']); ?></span>
        </div>
    <?php endif; ?>

    <?php if($is_already_recorded): ?>
        <div class="alert alert-info border-0 alert-dismissible">
            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
            <i class="icon-info22 mr-1"></i> <?php echo e(__('Staff attendance has already been recorded for this date. Modifying the entries below will update the records and log an audit trail.')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold">
                <?php echo e(__('Staff Members List')); ?> (<?php echo e(count($staff_users)); ?>)
                <span class="text-muted ml-2 font-size-sm">[<?php echo e($selected_date); ?> BS]</span>
            </h6>
            <div class="header-elements">
                <button type="button" class="btn btn-sm btn-outline-success mr-2" onclick="markAllStatus('present')"><i class="icon-checkmark4 mr-1"></i> <?php echo e(__('Mark All Present')); ?></button>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="markAllStatus('absent')"><i class="icon-cross2 mr-1"></i> <?php echo e(__('Mark All Absent')); ?></button>
            </div>
        </div>

        <div class="card-body">
            <form method="post" action="<?php echo e(route('staff_attendance.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="attendance_date_bs" value="<?php echo e($selected_date); ?>">

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Photo')); ?></th>
                            <th><?php echo e(__('Staff Name')); ?></th>
                            <th><?php echo e(__('Role / Type')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Remarks / Reason')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $staff_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $existing = $existing_records->get($u->id);
                                $curStatus = $existing ? $existing->status : 'present';
                                $curRemarks = $existing ? $existing->remarks : '';
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img class="rounded-circle" style="height: 38px; width: 38px;" src="<?php echo e($u->photo); ?>" alt="img"></td>
                                <td>
                                    <span class="font-weight-bold"><?php echo e($u->name); ?></span>
                                    <br>
                                    <span class="text-muted font-size-sm"><?php echo e($u->email); ?></span>
                                </td>
                                <td>
                                    <span class="badge badge-info p-1"><?php echo e(ucfirst(str_replace('_', ' ', $u->user_type))); ?></span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                        <label class="btn btn-sm btn-outline-success <?php echo e($curStatus === 'present' ? 'active' : ''); ?>">
                                            <input type="radio" name="staff[<?php echo e($u->id); ?>][status]" value="present" class="att-status" <?php echo e($curStatus === 'present' ? 'checked' : ''); ?>> <?php echo e(__('Present')); ?>

                                        </label>
                                        <label class="btn btn-sm btn-outline-danger <?php echo e($curStatus === 'absent' ? 'active' : ''); ?>">
                                            <input type="radio" name="staff[<?php echo e($u->id); ?>][status]" value="absent" class="att-status" <?php echo e($curStatus === 'absent' ? 'checked' : ''); ?>> <?php echo e(__('Absent')); ?>

                                        </label>
                                        <label class="btn btn-sm btn-outline-warning <?php echo e($curStatus === 'late' ? 'active' : ''); ?>">
                                            <input type="radio" name="staff[<?php echo e($u->id); ?>][status]" value="late" class="att-status" <?php echo e($curStatus === 'late' ? 'checked' : ''); ?>> <?php echo e(__('Late')); ?>

                                        </label>
                                        <label class="btn btn-sm btn-outline-info <?php echo e($curStatus === 'leave' ? 'active' : ''); ?>">
                                            <input type="radio" name="staff[<?php echo e($u->id); ?>][status]" value="leave" class="att-status" <?php echo e($curStatus === 'leave' ? 'checked' : ''); ?>> <?php echo e(__('Leave')); ?>

                                        </label>
                                        <label class="btn btn-sm btn-outline-secondary <?php echo e($curStatus === 'half_day' ? 'active' : ''); ?>">
                                            <input type="radio" name="staff[<?php echo e($u->id); ?>][status]" value="half_day" class="att-status" <?php echo e($curStatus === 'half_day' ? 'checked' : ''); ?>> <?php echo e(__('Half Day')); ?>

                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" name="staff[<?php echo e($u->id); ?>][remarks]" value="<?php echo e(old('staff.'.$u->id.'.remarks', $curRemarks)); ?>" class="form-control form-control-sm" placeholder="<?php echo e(__('Optional notes')); ?>">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-primary btn-lg" onclick="return confirm('<?php echo e(__('Are you sure you want to save staff attendance?')); ?>')">
                        <i class="icon-paperplane mr-2"></i> <?php echo e(__('Save Staff Attendance')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function markAllStatus(status) {
            var radios = document.querySelectorAll('.att-status[value="' + status + '"]');
            radios.forEach(function(radio) {
                radio.checked = true;
                var parentGroup = radio.closest('.btn-group');
                if (parentGroup) {
                    var labels = parentGroup.querySelectorAll('label');
                    labels.forEach(function(l) { l.classList.remove('active'); });
                    radio.parentElement.classList.add('active');
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\staff_attendance\index.blade.php ENDPATH**/ ?>