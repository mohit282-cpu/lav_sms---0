
<li class="nav-item">
    <a href="<?php echo e(route('my_children')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['my_children']) ? 'active' : ''); ?>"><i class="icon-users4"></i> <span><?php echo e(__('My Children')); ?></span></a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('tt.my_timetable')); ?>" class="nav-link <?php echo e(Route::is('tt.my_timetable') ? 'active' : ''); ?>"><i class="icon-calendar"></i> <span><?php echo e(__('Children Timetables')); ?></span></a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('books.catalogue')); ?>" class="nav-link <?php echo e(Route::is('books.catalogue') ? 'active' : ''); ?>"><i class="icon-books"></i> <span><?php echo e(__('Library Catalogue')); ?></span></a>
</li><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\parent\menu.blade.php ENDPATH**/ ?>