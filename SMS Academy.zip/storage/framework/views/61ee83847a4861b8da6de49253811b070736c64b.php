<?php $__env->startSection('page_title', __('Noticeboard')); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h6 class="card-title font-weight-bold"><i class="icon-newspaper mr-2"></i><?php echo e(__('School Noticeboard')); ?></h6>
        <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body">
        <?php if(Qs::userIsTeamSA()): ?>
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#all-notices" class="nav-link active" data-toggle="tab"><i class="icon-list mr-1"></i> <?php echo e(__('All Notices')); ?></a></li>
                <li class="nav-item"><a href="#new-notice" class="nav-link" data-toggle="tab"><i class="icon-plus2 mr-1"></i> <?php echo e(__('Create Notice')); ?></a></li>
            </ul>
        <?php endif; ?>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="all-notices">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="card border-left-3 <?php echo e($notice->is_published ? 'border-left-primary' : 'border-left-danger'); ?> shadow-sm h-100">
                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title font-weight-semibold mb-0">
                                            <a href="<?php echo e(route('notices.show', $notice->id)); ?>" class="text-default"><?php echo e($notice->title); ?></a>
                                        </h5>
                                        <?php if($notice->is_published): ?>
                                            <span class="badge badge-success"><?php echo e(__('Published')); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary"><?php echo e(__('Draft')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-muted font-size-xs mb-2">
                                        <i class="icon-calendar mr-1"></i>
                                        <?php echo e($notice->notice_date_bs ? $notice->notice_date_bs . ' BS' : $notice->notice_date->format('Y-m-d')); ?>

                                        <?php if($notice->expiry_date): ?>
                                            - <?php echo e($notice->expiry_date_bs ? $notice->expiry_date_bs . ' BS' : $notice->expiry_date->format('Y-m-d')); ?>

                                        <?php endif; ?>
                                    </div>
                                    <p class="card-text text-muted mb-3 flex-grow-1">
                                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($notice->content), 120)); ?>

                                    </p>
                                    <div class="font-size-xs text-muted mb-2">
                                        <span class="badge badge-light mr-1"><i class="icon-eye mr-1"></i><?php echo e(ucfirst($notice->role_visibility ?? 'All')); ?></span>
                                        <?php if($notice->my_class): ?>
                                            <span class="badge badge-info"><?php echo e($notice->my_class->name); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                        <a href="<?php echo e(route('notices.show', $notice->id)); ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="icon-eye mr-1"></i><?php echo e(__('Read More')); ?>

                                        </a>
                                        <?php if(Qs::userIsTeamSA()): ?>
                                            <div class="list-icons">
                                                <div class="dropdown">
                                                    <a href="#" class="list-icons-item" data-toggle="dropdown"><i class="icon-menu7"></i></a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a href="<?php echo e(route('notices.edit', $notice->id)); ?>" class="dropdown-item"><i class="icon-pencil"></i> <?php echo e(__('Edit')); ?></a>
                                                        <?php if(Qs::userIsSuperAdmin()): ?>
                                                            <a id="<?php echo e($notice->id); ?>" onclick="confirmDelete(this.id)" href="#" class="dropdown-item text-danger"><i class="icon-trash"></i> <?php echo e(__('Delete')); ?></a>
                                                            <form method="post" id="item-delete-<?php echo e($notice->id); ?>" action="<?php echo e(route('notices.destroy', $notice->id)); ?>" class="hidden"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?></form>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="alert alert-info border-0 alert-dismissible text-center">
                                <i class="icon-info22 mr-2"></i><?php echo e(__('No notices found at this time.')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($notices->links()); ?>

                </div>
            </div>

            <?php if(Qs::userIsTeamSA()): ?>
                <div class="tab-pane fade" id="new-notice">
                    <form method="post" action="<?php echo e(route('notices.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Notice Title')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="title" class="form-control" required value="<?php echo e(old('title')); ?>" placeholder="<?php echo e(__('Enter notice title')); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Content')); ?> <span class="text-danger">*</span></label>
                                    <textarea name="content" rows="8" class="form-control" required placeholder="<?php echo e(__('Enter notice description/content')); ?>"><?php echo e(old('content')); ?></textarea>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Notice Date (BS)')); ?></label>
                                    <input type="text" name="notice_date_bs" class="form-control nepali-datepicker" value="<?php echo e(old('notice_date_bs')); ?>" placeholder="YYYY-MM-DD">
                                </div>
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Expiry Date (BS)')); ?></label>
                                    <input type="text" name="expiry_date_bs" class="form-control nepali-datepicker" value="<?php echo e(old('expiry_date_bs')); ?>" placeholder="YYYY-MM-DD">
                                </div>
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Target Role Visibility')); ?></label>
                                    <select name="role_visibility" class="form-control select">
                                        <option value="all"><?php echo e(__('All Users')); ?></option>
                                        <option value="teacher"><?php echo e(__('Teachers Only')); ?></option>
                                        <option value="student"><?php echo e(__('Students Only')); ?></option>
                                        <option value="parent"><?php echo e(__('Parents Only')); ?></option>
                                        <option value="accountant"><?php echo e(__('Accountants Only')); ?></option>
                                        <option value="librarian"><?php echo e(__('Librarians Only')); ?></option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Specific Class (Optional)')); ?></label>
                                    <select name="my_class_id" class="form-control select">
                                        <option value=""><?php echo e(__('All Classes')); ?></option>
                                        <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="form-check form-check-switchery">
                                        <label class="form-check-label font-weight-semibold">
                                            <input type="checkbox" name="is_published" value="1" class="form-check-input-switchery" checked>
                                            <?php echo e(__('Publish Immediately')); ?>

                                        </label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block"><i class="icon-paperplane mr-2"></i><?php echo e(__('Post Notice')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\notices\index.blade.php ENDPATH**/ ?>