<!-- Main navbar -->
<div class="navbar navbar-expand-md navbar-dark">
    <div class="mt-2 mr-5">
        <a href="<?php echo e(route('dashboard')); ?>" class="d-inline-block">
            <h4 class="text-bold text-white"><?php echo e(Qs::getSystemName()); ?></h4>
        </a>
    </div>

    <div class="d-md-none">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-mobile">
            <i class="icon-tree5"></i>
        </button>
    </div>

    <div class="collapse navbar-collapse" id="navbar-mobile">
        <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown mr-md-2">
                <a href="#" class="navbar-nav-link dropdown-toggle" data-toggle="dropdown">
                    <i class="icon-earth mr-1"></i>
                    <span><?php echo e(app()->getLocale() == 'ne' ? 'नेपाली' : 'English'); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right language-switcher-dropdown">
                    <a href="<?php echo e(route('set_locale', 'ne')); ?>" class="dropdown-item <?php echo e(app()->getLocale() == 'ne' ? 'active' : ''); ?>">
                        <i class="icon-check <?php echo e(app()->getLocale() == 'ne' ? '' : 'invisible'); ?>"></i> नेपाली (Nepali)
                    </a>
                    <a href="<?php echo e(route('set_locale', 'en')); ?>" class="dropdown-item <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>">
                        <i class="icon-check <?php echo e(app()->getLocale() == 'en' ? '' : 'invisible'); ?>"></i> English
                    </a>
                </div>
            </li>

            <li class="nav-item dropdown">
                <a href="<?php echo e(route('home')); ?>" class="navbar-nav-link">
                    <i class="icon-home"></i>
                    <span class="d-md-none ml-2"><?php echo e(__('Dashboard')); ?></span>
                </a>
            </li>

            <li class="nav-item dropdown">
                <a href="<?php echo e(route('login')); ?>" class="navbar-nav-link">
                    <i class="icon-user-tie"></i>
                    <span class="d-md-none ml-2"><?php echo e(__('Sign in')); ?></span>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- /main navbar -->
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\partials\login\header.blade.php ENDPATH**/ ?>