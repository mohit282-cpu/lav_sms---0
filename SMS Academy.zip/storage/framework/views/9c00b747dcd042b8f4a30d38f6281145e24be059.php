
<li class="nav-item">
    <a href="<?php echo e(route('marks.year_selector', Qs::hash(Auth::user()->id))); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['marks.show', 'marks.year_selector', 'pins.enter']) ? 'active' : ''); ?>"><i class="icon-book"></i> <span><?php echo e(__('Marksheet')); ?></span></a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('tt.my_timetable')); ?>" class="nav-link <?php echo e(Route::is('tt.my_timetable') ? 'active' : ''); ?>"><i class="icon-calendar"></i> <span><?php echo e(__('Class Timetable')); ?></span></a>
</li>

<?php
    $studentRec = App\Models\StudentRecord::where('user_id', Auth::user()->id)->first();
?>
<?php if($studentRec): ?>
<li class="nav-item">
    <a href="<?php echo e(route('attendance.student_history', $studentRec->id)); ?>" class="nav-link <?php echo e(Route::is('attendance.student_history') ? 'active' : ''); ?>"><i class="icon-user-check"></i> <span><?php echo e(__('My Attendance')); ?></span></a>
</li>
<?php endif; ?>


<li class="nav-item">
    <a href="<?php echo e(route('payments.invoice', [Qs::hash(Auth::user()->id), Qs::getCurrentSession()])); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['payments.invoice', 'payments.receipts']) ? 'active' : ''); ?>"><i class="icon-cash"></i> <span><?php echo e(__('Fees & Payments')); ?></span></a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('books.index')); ?>" class="nav-link <?php echo e(Route::is('books.index') ? 'active' : ''); ?>"><i class="icon-books"></i> <span><?php echo e(__('Library Catalogue')); ?></span></a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('book_requests.index')); ?>" class="nav-link <?php echo e(Route::is('book_requests.index') ? 'active' : ''); ?>"><i class="icon-list3"></i> <span><?php echo e(__('My Book Requests')); ?></span></a>
</li>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\student\menu.blade.php ENDPATH**/ ?>