<!-- Theme JS files -->
<script src="<?php echo e(asset('global_assets/js/plugins/extensions/jquery_ui/interactions.min.js')); ?> "></script>
<script src="<?php echo e(asset('global_assets/js/plugins/forms/selects/select2.min.js')); ?> "></script>


<script src="<?php echo e(asset('global_assets/js/plugins/forms/wizards/steps.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/forms/inputs/inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/forms/validation/validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/extensions/cookie.js')); ?>"></script>


<script type="text/javascript" src="<?php echo e(asset('global_assets/js/plugins/notifications/sweet_alert2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('global_assets/js/plugins/notifications/pnotify.min.js')); ?>"></script>


<script src="<?php echo e(asset('global_assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/tables/datatables/extensions/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/tables/datatables/extensions/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/tables/datatables/extensions/pdfmake/vfs_fonts.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/tables/datatables/extensions/buttons.min.js')); ?>"></script>


<script src="<?php echo e(asset('global_assets/js/plugins/ui/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/pickers/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/plugins/pickers/pickadate/legacy.js')); ?>"></script>


<script src="<?php echo e(asset('global_assets/js/plugins/uploaders/fileinput/fileinput.min.js')); ?>"></script>


<script src="<?php echo e(asset('global_assets/js/plugins/ui/fullcalendar/fullcalendar.min.js')); ?>"></script>


<script src=" <?php echo e(asset('assets/js/app.js')); ?> "></script>
<script src="<?php echo e(asset('global_assets/js/demo_pages/form_wizard.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/demo_pages/form_select2.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/demo_pages/datatables_extension_buttons_html5.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/demo_pages/uploader_bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('global_assets/js/demo_pages/fullcalendar_basic.js')); ?>"></script>

<!-- /theme JS files -->

<script src=" <?php echo e(asset('assets/js/custom.js')); ?> "></script>
<script src=" <?php echo e(asset('assets/js/nepali_datepicker.js')); ?> "></script>


<script>
    window.PWA_SW_PATH = "<?php echo e(route('pwa.sw')); ?>";
    window.PWA_USER_ID = <?php echo e(Auth::check() ? Auth::id() : 'null'); ?>;
    window.PWA_ATTENDANCE_SYNC_URL = "<?php echo e(route('attendance.sync')); ?>";
    window.PWA_ICON_PATH = "<?php echo e(asset('assets/images/icons/icon-192x192.png')); ?>";
    window.PWA_APP_NAME = "<?php echo e(Qs::getSystemName()); ?>";
    window.PWA_I18N_UPDATE = "<?php echo e(__('A new version of the school portal is ready.')); ?>";
    window.PWA_I18N_UPDATE_BTN = "<?php echo e(__('Update Now')); ?>";
    window.PWA_I18N_INSTALL_DESC = "<?php echo e(__('Install school portal for quick and reliable access')); ?>";
    window.PWA_I18N_INSTALL_BTN = "<?php echo e(__('Install App')); ?>";
    window.PWA_I18N_ONLINE = "<?php echo e(__('Connection Restored')); ?>";
    window.PWA_I18N_OFFLINE = "<?php echo e(__('Offline Mode - Live actions require connection')); ?>";
    window.PWA_VAPID_PUBLIC_KEY = "<?php echo e(config('services.pwa.vapid_public_key', '')); ?>";
    window.PWA_VAPID_PUBLIC_KEY_URL = "<?php echo e(route('pwa.push.vapid')); ?>";
    window.PWA_PUSH_SUBSCRIBE_URL = "<?php echo e(route('pwa.push.subscribe')); ?>";
    window.PWA_PUSH_UNSUBSCRIBE_URL = "<?php echo e(route('pwa.push.unsubscribe')); ?>";
    window.PWA_PUSH_TEST_URL = "<?php echo e(route('pwa.push.test')); ?>";
</script>
<script src="<?php echo e(asset('assets/js/pwa.js')); ?>"></script>

<?php echo $__env->make('partials.js.custom_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/partials/inc_bottom.blade.php ENDPATH**/ ?>