<?php $__env->startSection('page_title', __('Manage Examinations')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('Manage Examinations & Terminal Evaluations')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#all-exams" class="nav-link active" data-toggle="tab"><i class="icon-list mr-1"></i> <?php echo e(__('All Examinations')); ?></a></li>
                <li class="nav-item"><a href="#new-exam" class="nav-link" data-toggle="tab"><i class="icon-plus2 mr-1"></i> <?php echo e(__('Create Examination')); ?></a></li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade show active" id="all-exams">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Exam Name')); ?></th>
                            <th><?php echo e(__('Evaluation Type')); ?></th>
                            <th><?php echo e(__('Term')); ?></th>
                            <th><?php echo e(__('Session')); ?></th>
                            <th><?php echo e(__('Dates (BS)')); ?></th>
                            <th><?php echo e(__('Result Status')); ?></th>
                            <th><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-semibold"><?php echo e($ex->name); ?></td>
                                <td><?php echo e(ucwords(str_replace('_', ' ', $ex->exam_type ?? 'terminal'))); ?></td>
                                <td><?php echo e(__('Term')); ?> <?php echo e($ex->term); ?></td>
                                <td><?php echo e($ex->year); ?></td>
                                <td>
                                    <?php if($ex->start_date_bs): ?>
                                        <?php echo e($ex->start_date_bs); ?> <?php if($ex->end_date_bs && $ex->end_date_bs !== $ex->start_date_bs): ?> - <?php echo e($ex->end_date_bs); ?> <?php endif; ?> BS
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(($ex->status ?? 'published') === 'published'): ?>
                                        <span class="badge badge-success p-2"><?php echo e(__('Published')); ?></span>
                                    <?php elseif($ex->status === 'completed'): ?>
                                        <span class="badge badge-info p-2"><?php echo e(__('Completed (Unpublished)')); ?></span>
                                    <?php elseif($ex->status === 'ongoing'): ?>
                                        <span class="badge badge-warning p-2 text-white"><?php echo e(__('Ongoing')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary p-2"><?php echo e(ucfirst($ex->status ?? 'Draft')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="list-icons">
                                        <div class="dropdown">
                                            <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                <i class="icon-menu9"></i>
                                            </a>

                                            <div class="dropdown-menu dropdown-menu-left">
                                                <?php if(Qs::userIsTeamSA()): ?>
                                                    <a href="<?php echo e(route('exams.edit', $ex->id)); ?>" class="dropdown-item"><i class="icon-pencil"></i> <?php echo e(__('Edit')); ?></a>

                                                    <?php if(($ex->status ?? 'published') !== 'published'): ?>
                                                        <form method="post" action="<?php echo e(route('exams.publish', $ex->id)); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                                                            <button type="submit" class="dropdown-item text-success"><i class="icon-checkmark"></i> <?php echo e(__('Publish Results')); ?></button>
                                                        </form>
                                                    <?php else: ?>
                                                        <form method="post" action="<?php echo e(route('exams.unpublish', $ex->id)); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                                                            <button type="submit" class="dropdown-item text-warning"><i class="icon-eye-blocked"></i> <?php echo e(__('Unpublish Results')); ?></button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <?php if(Qs::userIsSuperAdmin()): ?>
                                                    <form method="post" action="<?php echo e(route('exams.destroy', $ex->id)); ?>" onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this examination?')); ?>');">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                        <button type="submit" class="dropdown-item text-danger"><i class="icon-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="new-exam">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-info border-0 alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                                <span><?php echo e(__('Creating Examination for Academic Session:')); ?> <strong><?php echo e(Qs::getCurrentSession()); ?></strong></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <form method="post" action="<?php echo e(route('exams.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Exam Name')); ?> <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="name" value="<?php echo e(old('name')); ?>" required type="text" class="form-control" placeholder="e.g. First Terminal Examination">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Evaluation Type')); ?> <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select class="form-control select" name="exam_type">
                                            <option value="first_terminal"><?php echo e(__('First Terminal Examination (प्रथम त्रैमासिक)')); ?></option>
                                            <option value="second_terminal"><?php echo e(__('Second Terminal Examination (दोस्रो त्रैमासिक)')); ?></option>
                                            <option value="third_terminal"><?php echo e(__('Third Terminal Examination (तेस्रो त्रैमासिक)')); ?></option>
                                            <option value="mid_term"><?php echo e(__('Mid-Term Examination (मध्यसत्र)')); ?></option>
                                            <option value="annual"><?php echo e(__('Annual Examination (वार्षिक परीक्षा)')); ?></option>
                                            <option value="unit_test"><?php echo e(__('Unit Test / Continuous Assessment (एकाइ परीक्षा)')); ?></option>
                                            <option value="practical"><?php echo e(__('Practical / Project Evaluation (प्रयोगात्मक परीक्षा)')); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="term" class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Term')); ?> <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select class="form-control select" name="term" id="term" required>
                                            <option <?php echo e(old('term') == 1 ? 'selected' : ''); ?> value="1"><?php echo e(__('Term 1 (प्रथम सत्र)')); ?></option>
                                            <option <?php echo e(old('term') == 2 ? 'selected' : ''); ?> value="2"><?php echo e(__('Term 2 (दोस्रो सत्र)')); ?></option>
                                            <option <?php echo e(old('term') == 3 ? 'selected' : ''); ?> value="3"><?php echo e(__('Term 3 (तेस्रो सत्र)')); ?></option>
                                            <option <?php echo e(old('term') == 4 ? 'selected' : ''); ?> value="4"><?php echo e(__('Term 4 (चौथो सत्र)')); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Start Date (BS)')); ?>:</label>
                                    <div class="col-lg-9">
                                        <input name="start_date_bs" value="<?php echo e(old('start_date_bs')); ?>" type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('End Date (BS)')); ?>:</label>
                                    <div class="col-lg-9">
                                        <input name="end_date_bs" value="<?php echo e(old('end_date_bs')); ?>" type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Initial Status')); ?>:</label>
                                    <div class="col-lg-9">
                                        <select class="form-control select" name="status">
                                            <option value="draft"><?php echo e(__('Draft (मस्यौदा)')); ?></option>
                                            <option value="scheduled"><?php echo e(__('Scheduled (तालिकाबद्ध)')); ?></option>
                                            <option value="ongoing"><?php echo e(__('Ongoing (सञ्चालनमा)')); ?></option>
                                            <option value="completed"><?php echo e(__('Completed (सम्पन्न)')); ?></option>
                                            <option value="published" selected><?php echo e(__('Published (प्रकाशित)')); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Description')); ?>:</label>
                                    <div class="col-lg-9">
                                        <textarea name="description" class="form-control" rows="2" placeholder="<?php echo e(__('Optional notes or guidelines')); ?>"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                </div>

                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Create Examination')); ?> <i class="icon-paperplane ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\exams\index.blade.php ENDPATH**/ ?>