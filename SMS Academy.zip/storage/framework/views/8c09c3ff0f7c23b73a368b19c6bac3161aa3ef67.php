<?php $__env->startSection('page_title', __('Library Circulations: Issue & Return')); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="row mb-3">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <h4 class="mb-0 font-weight-semibold">
                <i class="icon-sync mr-2 text-primary"></i><?php echo e(__('Circulation Management')); ?>

            </h4>
            <?php if(Qs::userIsTeamLibrary()): ?>
                <button type="button" class="btn btn-primary font-weight-bold" data-toggle="modal" data-target="#modal-issue-book">
                    <i class="icon-plus2 mr-2"></i><?php echo e(__('Issue Book to Borrower')); ?>

                </button>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-semibold"><?php echo e(__('Circulation Records')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item">
                    <a href="#active-loans" class="nav-link active" data-toggle="tab">
                        <i class="icon-reading mr-2"></i><?php echo e(__('Active Issued Books')); ?> (<?php echo e(count($active_loans)); ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#overdue-loans" class="nav-link" data-toggle="tab">
                        <i class="icon-alarm mr-2 text-danger"></i>
                        <span class="text-danger"><?php echo e(__('Overdue Loans')); ?> (<?php echo e(count($overdue_loans)); ?>)</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#returned-history" class="nav-link" data-toggle="tab">
                        <i class="icon-history mr-2"></i><?php echo e(__('Returned History')); ?> (<?php echo e(count($returned_loans)); ?>)
                    </a>
                </li>
            </ul>

            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="active-loans">
                    <table class="table datatable-button-html5-columns table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Book Title')); ?></th>
                            <th><?php echo e(__('Borrower')); ?></th>
                            <th><?php echo e(__('Borrower Role')); ?></th>
                            <th><?php echo e(__('Issue Date (BS)')); ?></th>
                            <th><?php echo e(__('Due Date (BS)')); ?></th>
                            <th><?php echo e(__('Days Left / Overdue')); ?></th>
                            <th><?php echo e(__('Issued By')); ?></th>
                            <th class="text-center"><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $active_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $today = \Carbon\Carbon::today();
                                $dueDate = \Carbon\Carbon::parse($loan->due_date);
                                $isOverdue = $today->gt($dueDate);
                                $daysDiff = abs($today->diffInDays($dueDate, false));
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <a href="<?php echo e(route('books.show', $loan->book_id)); ?>" class="font-weight-semibold">
                                        <?php echo e($loan->book ? $loan->book->name : '-'); ?>

                                    </a>
                                    <?php if($loan->book && $loan->book->isbn): ?>
                                        <div class="text-muted font-size-xs">ISBN: <?php echo e($loan->book->isbn); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="font-weight-semibold"><?php echo e($loan->user ? $loan->user->name : '-'); ?></div>
                                    <div class="text-muted font-size-xs"><?php echo e($loan->user ? $loan->user->email : ''); ?></div>
                                </td>
                                <td>
                                    <span class="badge badge-light border-left-info badge-striped">
                                        <?php echo e(ucfirst($loan->borrower_type)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($loan->issue_date_bs ?: $loan->issue_date); ?></td>
                                <td><?php echo e($loan->due_date_bs ?: $loan->due_date); ?></td>
                                <td>
                                    <?php if($isOverdue): ?>
                                        <span class="badge badge-danger font-weight-bold">
                                            <?php echo e(__('Overdue by :days days', ['days' => $daysDiff])); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-success">
                                            <?php echo e(__(':days days remaining', ['days' => $daysDiff])); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($loan->issuer ? $loan->issuer->name : '-'); ?></td>
                                <td class="text-center">
                                    <?php if(Qs::userIsTeamLibrary()): ?>
                                        <button type="button" class="btn btn-sm btn-outline-success font-weight-bold" onclick="openReturnModal(<?php echo e($loan->id); ?>, '<?php echo e(addslashes($loan->book ? $loan->book->name : '')); ?>', '<?php echo e(addslashes($loan->user ? $loan->user->name : '')); ?>', '<?php echo e($isOverdue ? 1 : 0); ?>')">
                                            <i class="icon-undo mr-1"></i> <?php echo e(__('Return Book')); ?>

                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="tab-pane fade" id="overdue-loans">
                    <table class="table datatable-button-html5-columns table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Book Title')); ?></th>
                            <th><?php echo e(__('Borrower')); ?></th>
                            <th><?php echo e(__('Borrower Role')); ?></th>
                            <th><?php echo e(__('Due Date (BS)')); ?></th>
                            <th><?php echo e(__('Due Date (AD)')); ?></th>
                            <th><?php echo e(__('Days Overdue')); ?></th>
                            <th class="text-center"><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $overdue_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $daysOverdue = abs(\Carbon\Carbon::today()->diffInDays(\Carbon\Carbon::parse($ov->due_date), false));
                            ?>
                            <tr class="table-danger">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <a href="<?php echo e(route('books.show', $ov->book_id)); ?>" class="font-weight-semibold text-danger">
                                        <?php echo e($ov->book ? $ov->book->name : '-'); ?>

                                    </a>
                                </td>
                                <td>
                                    <div class="font-weight-semibold"><?php echo e($ov->user ? $ov->user->name : '-'); ?></div>
                                    <div class="text-muted font-size-xs"><?php echo e($ov->user ? $ov->user->phone : ''); ?></div>
                                </td>
                                <td><span class="badge badge-danger"><?php echo e(ucfirst($ov->borrower_type)); ?></span></td>
                                <td class="font-weight-bold"><?php echo e($ov->due_date_bs); ?></td>
                                <td><?php echo e($ov->due_date); ?></td>
                                <td>
                                    <span class="badge badge-danger font-weight-bold"><?php echo e($daysOverdue); ?> <?php echo e(__('Days')); ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if(Qs::userIsTeamLibrary()): ?>
                                        <button type="button" class="btn btn-sm btn-danger font-weight-bold" onclick="openReturnModal(<?php echo e($ov->id); ?>, '<?php echo e(addslashes($ov->book ? $ov->book->name : '')); ?>', '<?php echo e(addslashes($ov->user ? $ov->user->name : '')); ?>', 1)">
                                            <i class="icon-undo mr-1"></i> <?php echo e(__('Record Return')); ?>

                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="tab-pane fade" id="returned-history">
                    <table class="table datatable-button-html5-columns table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Book Title')); ?></th>
                            <th><?php echo e(__('Borrower')); ?></th>
                            <th><?php echo e(__('Issue Date (BS)')); ?></th>
                            <th><?php echo e(__('Returned Date (BS)')); ?></th>
                            <th><?php echo e(__('Received By')); ?></th>
                            <th><?php echo e(__('Fine (NPR)')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $returned_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <a href="<?php echo e(route('books.show', $ret->book_id)); ?>" class="font-weight-semibold">
                                        <?php echo e($ret->book ? $ret->book->name : '-'); ?>

                                    </a>
                                </td>
                                <td><?php echo e($ret->user ? $ret->user->name : '-'); ?></td>
                                <td><?php echo e($ret->issue_date_bs ?: $ret->issue_date); ?></td>
                                <td><?php echo e($ret->return_date_bs ?: ($ret->return_date ?: '-')); ?></td>
                                <td><?php echo e($ret->receiver ? $ret->receiver->name : '-'); ?></td>
                                <td>
                                    <?php if($ret->fine_amount > 0): ?>
                                        <span class="badge badge-danger">Rs. <?php echo e(number_format($ret->fine_amount, 2)); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">Rs. 0.00</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge badge-success"><?php echo e(__('Returned')); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(Qs::userIsTeamLibrary()): ?>
        <div id="modal-issue-book" class="modal fade" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h6 class="modal-title font-weight-semibold"><i class="icon-reading mr-2"></i><?php echo e(__('Issue Book to Student or Staff')); ?></h6>
                        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                    </div>

                    <form method="post" action="<?php echo e(route('books.issue_book')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Select Book')); ?> <span class="text-danger">*</span></label>
                                        <select class="form-control select" name="book_id" required>
                                            <option value=""><?php echo e(__('Choose a Book...')); ?></option>
                                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($b->id); ?>" <?php echo e((request('book_id') == $b->id) ? 'selected' : ''); ?>>
                                                    <?php echo e($b->name); ?> (<?php echo e(__('Available')); ?>: <?php echo e($b->available_copies); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Select Borrower')); ?> <span class="text-danger">*</span></label>
                                        <select class="form-control select" name="user_id" required>
                                            <option value=""><?php echo e(__('Choose Student or Staff...')); ?></option>
                                            <?php $__currentLoopData = $borrowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($borrower->id); ?>">
                                                    <?php echo e($borrower->name); ?> [<?php echo e(strtoupper($borrower->user_type)); ?>] (<?php echo e($borrower->email); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Issue Date (BS - YYYY-MM-DD)')); ?> <span class="text-danger">*</span></label>
                                        <input type="text" name="issue_date_bs" value="<?php echo e($today_bs); ?>" class="form-control" required placeholder="YYYY-MM-DD">
                                        <span class="form-text text-muted font-size-xs"><?php echo e(__('Default: Today in Bikram Sambat')); ?></span>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Due Date (BS - YYYY-MM-DD)')); ?> <span class="text-danger">*</span></label>
                                        <input type="text" name="due_date_bs" value="<?php echo e($default_due_bs); ?>" class="form-control" required placeholder="YYYY-MM-DD">
                                        <span class="form-text text-muted font-size-xs"><?php echo e(__('Default loan period: 14 days')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-semibold"><?php echo e(__('Circulation Notes (Optional)')); ?></label>
                                <textarea name="notes" rows="2" class="form-control" placeholder="<?php echo e(__('e.g. Clean condition, issued for class project')); ?>"></textarea>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                            <button type="submit" class="btn btn-primary font-weight-bold">
                                <i class="icon-check mr-2"></i><?php echo e(__('Confirm & Issue Book')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
        <div id="modal-return-book" class="modal fade" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h6 class="modal-title font-weight-semibold"><i class="icon-undo mr-2"></i><?php echo e(__('Process Book Return')); ?></h6>
                        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                    </div>

                    <form id="form-return-book" method="post" action="">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="alert alert-info border-0">
                                <strong><?php echo e(__('Book:')); ?></strong> <span id="return-book-title"></span><br>
                                <strong><?php echo e(__('Borrower:')); ?></strong> <span id="return-borrower-name"></span>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-semibold"><?php echo e(__('Return Date (BS - YYYY-MM-DD)')); ?> <span class="text-danger">*</span></label>
                                <input type="text" name="return_date_bs" value="<?php echo e($today_bs); ?>" class="form-control" required>
                            </div>

                            <div class="form-group" id="fine-section">
                                <label class="font-weight-semibold"><?php echo e(__('Overdue Fine Amount (NPR / Rs.)')); ?></label>
                                <input type="number" step="0.01" min="0" name="fine_amount" value="0.00" class="form-control">
                                <span class="form-text text-muted font-size-xs"><?php echo e(__('Optional fine if returned past due date')); ?></span>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-semibold"><?php echo e(__('Return Condition / Notes')); ?></label>
                                <textarea name="notes" rows="2" class="form-control" placeholder="<?php echo e(__('e.g. Good condition, returned on time')); ?>"></textarea>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                            <button type="submit" class="btn btn-success font-weight-bold">
                                <i class="icon-check mr-2"></i><?php echo e(__('Record Book Return')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function openReturnModal(requestId, bookTitle, borrowerName, isOverdue) {
        var actionUrl = "<?php echo e(url('books/circulations')); ?>/" + requestId + "/return";
        $('#form-return-book').attr('action', actionUrl);
        $('#return-book-title').text(bookTitle);
        $('#return-borrower-name').text(borrowerName);
        if (isOverdue) {
            $('#fine-section').show();
        }
        $('#modal-return-book').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\circulations.blade.php ENDPATH**/ ?>