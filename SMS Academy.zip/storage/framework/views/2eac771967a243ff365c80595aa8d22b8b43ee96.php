<?php $__env->startSection('page_title', __('Children Timetables')); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h6 class="card-title font-weight-bold"><i class="icon-calendar mr-2"></i><?php echo e(__('Select Child to View Timetable')); ?></h6>
        <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card border border-primary shadow-sm h-100">
                        <div class="card-body text-center">
                            <img src="<?php echo e($ch->user->photo); ?>" class="rounded-circle mb-2" width="60" height="60" alt="photo">
                            <h6 class="font-weight-bold mb-1"><?php echo e($ch->user->name); ?></h6>
                            <p class="text-muted font-size-sm mb-3"><?php echo e($ch->my_class->name ?? ''); ?> (<?php echo e($ch->section->name ?? ''); ?>)</p>
                            <a href="<?php echo e(route('tt.student_timetable', Qs::hash($ch->user->id))); ?>" class="btn btn-primary btn-sm btn-block">
                                <i class="icon-eye mr-1"></i><?php echo e(__('View Timetable')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center text-muted py-4">
                    <i class="icon-user-cancel icon-2x mb-2 d-block"></i>
                    <?php echo e(__('No linked children found.')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\timetables\parent_children_timetable.blade.php ENDPATH**/ ?>