<?php $__env->startSection('page_title', __('My Teaching Timetable')); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h6 class="card-title font-weight-bold"><i class="icon-calendar mr-2"></i><?php echo e(__('My Weekly Teaching Schedule')); ?></h6>
        <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body">
        <?php if($tts->isEmpty()): ?>
            <div class="text-center text-muted py-4">
                <i class="icon-calendar-cross icon-2x mb-2 d-block"></i>
                <?php echo e(__('No scheduled teaching classes assigned to you in the timetable yet.')); ?>

            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered text-center">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th><?php echo e(__('Day / Date')); ?></th>
                            <th><?php echo e(__('Time Slot')); ?></th>
                            <th><?php echo e(__('Class')); ?></th>
                            <th><?php echo e(__('Subject')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tts->sortBy('day'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="font-weight-bold"><?php echo e($t->exam_date ?? $t->day); ?></td>
                                <td><span class="badge badge-light font-size-sm"><?php echo e($t->time_slot->full ?? '-'); ?></span></td>
                                <td><span class="badge badge-info"><?php echo e($t->tt_record->my_class->name ?? '-'); ?></span></td>
                                <td class="font-weight-semibold"><?php echo e($t->subject->name ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\timetables\teacher_timetable.blade.php ENDPATH**/ ?>