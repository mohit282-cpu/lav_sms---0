<?php $__env->startSection('page_title', __('Study Materials & E-Learning')); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h6 class="card-title font-weight-bold"><i class="icon-file-text2 mr-2"></i><?php echo e(__('Study Materials & Lecture Notes')); ?></h6>
        <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body">
        <?php if(in_array(Auth::user()->user_type, ['super_admin', 'admin', 'teacher'])): ?>
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#all-materials" class="nav-link active" data-toggle="tab"><i class="icon-list mr-1"></i> <?php echo e(__('All Study Materials')); ?></a></li>
                <li class="nav-item"><a href="#upload-material" class="nav-link" data-toggle="tab"><i class="icon-upload mr-1"></i> <?php echo e(__('Upload New Material')); ?></a></li>
            </ul>
        <?php endif; ?>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="all-materials">
                
                <form method="get" action="<?php echo e(route('study_materials.index')); ?>" class="mb-3">
                    <div class="row">
                        <div class="col-md-4">
                            <select name="class_id" class="form-control select">
                                <option value=""><?php echo e(__('Filter by Class (All)')); ?></option>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(request('class_id') == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary"><i class="icon-filter3 mr-1"></i><?php echo e(__('Filter')); ?></button>
                            <a href="<?php echo e(route('study_materials.index')); ?>" class="btn btn-light"><i class="icon-reset mr-1"></i><?php echo e(__('Reset')); ?></a>
                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="bg-light">
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Title')); ?></th>
                                <th><?php echo e(__('Class')); ?></th>
                                <th><?php echo e(__('Subject')); ?></th>
                                <th><?php echo e(__('Uploaded By')); ?></th>
                                <th><?php echo e(__('Format / Size')); ?></th>
                                <th><?php echo e(__('Date')); ?></th>
                                <th class="text-center"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <div class="font-weight-semibold"><?php echo e($material->title); ?></div>
                                        <?php if($material->description): ?>
                                            <div class="text-muted font-size-xs"><?php echo e(\Illuminate\Support\Str::limit($material->description, 60)); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-primary"><?php echo e($material->my_class->name ?? '-'); ?></span>
                                        <?php if($material->section): ?>
                                            <span class="badge badge-info"><?php echo e($material->section->name); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($material->subject->name ?? __('General')); ?></td>
                                    <td><?php echo e($material->teacher->name ?? '-'); ?></td>
                                    <td>
                                        <span class="badge badge-dark text-uppercase"><?php echo e($material->file_type); ?></span>
                                        <span class="font-size-xs text-muted ml-1"><?php echo e(round($material->file_size / 1024, 1)); ?> KB</span>
                                    </td>
                                    <td><?php echo e($material->created_at->format('Y-m-d')); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('study_materials.download', $material->id)); ?>" class="btn btn-outline-success btn-sm" title="<?php echo e(__('Download')); ?>">
                                            <i class="icon-download mr-1"></i><?php echo e(__('Download')); ?>

                                        </a>
                                        <?php if(Qs::userIsSuperAdmin() || $material->teacher_id === Auth::id()): ?>
                                            <a id="<?php echo e($material->id); ?>" onclick="confirmDelete(this.id)" href="#" class="btn btn-outline-danger btn-sm ml-1" title="<?php echo e(__('Delete')); ?>">
                                                <i class="icon-trash"></i>
                                            </a>
                                            <form method="post" id="item-delete-<?php echo e($material->id); ?>" action="<?php echo e(route('study_materials.destroy', $material->id)); ?>" class="hidden">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="icon-folder-open2 icon-2x mb-2 d-block"></i>
                                        <?php echo e(__('No study materials found.')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($materials->appends(request()->query())->links()); ?>

                </div>
            </div>

            <?php if(in_array(Auth::user()->user_type, ['super_admin', 'admin', 'teacher'])): ?>
                <div class="tab-pane fade" id="upload-material">
                    <form method="post" action="<?php echo e(route('study_materials.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Material Title')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="title" class="form-control" required value="<?php echo e(old('title')); ?>" placeholder="<?php echo e(__('e.g. Chapter 4 Thermodynamics Notes')); ?>">
                                </div>

                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Class')); ?> <span class="text-danger">*</span></label>
                                    <select name="my_class_id" class="form-control select" required>
                                        <option value=""><?php echo e(__('Select Class')); ?></option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('my_class_id') == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Subject (Optional)')); ?></label>
                                    <select name="subject_id" class="form-control select">
                                        <option value=""><?php echo e(__('All / General Subject')); ?></option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('subject_id') == $sub->id ? 'selected' : ''); ?> value="<?php echo e($sub->id); ?>"><?php echo e($sub->name); ?> (<?php echo e($sub->my_class->name ?? ''); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('File Upload')); ?> <span class="text-danger">*</span></label>
                                    <input type="file" name="material_file" class="form-control-uniform" required accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.zip,.png,.jpg,.jpeg">
                                    <small class="form-text text-muted"><?php echo e(__('Accepted formats: PDF, DOC, PPT, XLS, ZIP, TXT, Images. Max 10MB.')); ?></small>
                                </div>

                                <div class="form-group">
                                    <label class="font-weight-semibold"><?php echo e(__('Description / Instructions')); ?></label>
                                    <textarea name="description" rows="4" class="form-control" placeholder="<?php echo e(__('Optional reading instructions or summary')); ?>"><?php echo e(old('description')); ?></textarea>
                                </div>

                                <button type="submit" class="btn btn-success btn-block mt-4"><i class="icon-upload mr-2"></i><?php echo e(__('Upload Material')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\study_materials\index.blade.php ENDPATH**/ ?>