<div class="sidebar sidebar-dark sidebar-main sidebar-expand-md">

    <!-- Sidebar mobile toggler -->
    <div class="sidebar-mobile-toggler text-center">
        <a href="#" class="sidebar-mobile-main-toggle">
            <i class="icon-arrow-left8"></i>
        </a>
        <?php echo e(__('Navigation')); ?>

        <a href="#" class="sidebar-mobile-expand">
            <i class="icon-screen-full"></i>
            <i class="icon-screen-normal"></i>
        </a>
    </div>
    <!-- /sidebar mobile toggler -->

    <!-- Sidebar content -->
    <div class="sidebar-content">

        <!-- User menu -->
        <div class="sidebar-user">
            <div class="card-body">
                <div class="media">
                    <div class="mr-3">
                        <a href="<?php echo e(route('my_account')); ?>"><img src="<?php echo e(Auth::user()->photo); ?>" width="38" height="38" class="rounded-circle" alt="photo"></a>
                    </div>

                    <div class="media-body">
                        <div class="media-title font-weight-semibold"><?php echo e(Auth::user()->name); ?></div>
                        <div class="font-size-xs opacity-50">
                            <i class="icon-user font-size-sm"></i> &nbsp;<?php echo e(__(ucwords(str_replace('_', ' ', Auth::user()->user_type)))); ?>

                        </div>
                    </div>

                    <div class="ml-3 align-self-center">
                        <a href="<?php echo e(route('my_account')); ?>" class="text-white"><i class="icon-cog3"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /user menu -->

        <!-- Main navigation -->
        <div class="card card-sidebar-mobile">
            <ul class="nav nav-sidebar" data-nav-type="accordion">

                <!-- Main -->
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e((Route::is('dashboard')) ? 'active' : ''); ?>">
                        <i class="icon-home4"></i>
                        <span><?php echo e(__('Dashboard')); ?></span>
                    </a>
                </li>

                
                <?php if(Qs::userIsAcademic()): ?>
                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['tt.index', 'ttr.edit', 'ttr.show', 'ttr.manage']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                        <a href="#" class="nav-link"><i class="icon-graduation2"></i> <span> <?php echo e(__('Academics')); ?></span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Manage Academics')); ?>">

                        
                            <li class="nav-item"><a href="<?php echo e(route('tt.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['tt.index']) ? 'active' : ''); ?>"><?php echo e(__('Timetables')); ?></a></li>
                        </ul>
                    </li>
                    <?php endif; ?>

                
                <?php if(Qs::userIsAdministrative()): ?>
                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.create', 'payments.invoice', 'payments.receipts', 'payments.edit', 'payments.manage', 'payments.show',]) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                        <a href="#" class="nav-link"><i class="icon-office"></i> <span> <?php echo e(__('Administrative')); ?></span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Administrative')); ?>">

                            
                            <?php if(Qs::userIsTeamAccount()): ?>
                            <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.create', 'payments.edit', 'payments.manage', 'payments.show', 'payments.invoice']) ? 'nav-item-expanded' : ''); ?>">

                                <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.edit', 'payments.create', 'payments.manage', 'payments.show', 'payments.invoice']) ? 'active' : ''); ?>"><?php echo e(__('Payments')); ?></a>

                                <ul class="nav nav-group-sub">
                                    <li class="nav-item"><a href="<?php echo e(route('payments.create')); ?>" class="nav-link <?php echo e(Route::is('payments.create') ? 'active' : ''); ?>"><?php echo e(__('Create Payment')); ?></a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('payments.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.edit', 'payments.show']) ? 'active' : ''); ?>"><?php echo e(__('Manage Payments')); ?></a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('payments.manage')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['payments.manage', 'payments.invoice', 'payments.receipts']) ? 'active' : ''); ?>"><?php echo e(__('Student Payments')); ?></a></li>

                                </ul>

                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <?php if(Qs::userIsTeamSAT()): ?>
                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                        <a href="#" class="nav-link"><i class="icon-users"></i> <span> <?php echo e(__('Students')); ?></span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Manage Students')); ?>">
                            
                            <?php if(Qs::userIsTeamSA()): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('students.create')); ?>"
                                       class="nav-link <?php echo e((Route::is('students.create')) ? 'active' : ''); ?>"><?php echo e(__('Admit Student')); ?></a>
                                </li>
                            <?php endif; ?>

                            
                            <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.list', 'students.edit', 'students.show']) ? 'nav-item-expanded' : ''); ?>">
                                <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.list', 'students.edit', 'students.show']) ? 'active' : ''); ?>"><?php echo e(__('Student Information')); ?></a>
                                <ul class="nav nav-group-sub">
                                    <?php $__currentLoopData = App\Models\MyClass::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item"><a href="<?php echo e(route('students.list', $c->id)); ?>" class="nav-link "><?php echo e($c->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>

                            <?php if(Qs::userIsTeamSA()): ?>

                            
                            <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.promotion', 'students.promotion_manage']) ? 'nav-item-expanded' : ''); ?>"><a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.promotion', 'students.promotion_manage' ]) ? 'active' : ''); ?>"><?php echo e(__('Student Promotion')); ?></a>
                            <ul class="nav nav-group-sub">
                                <li class="nav-item"><a href="<?php echo e(route('students.promotion')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.promotion']) ? 'active' : ''); ?>"><?php echo e(__('Promote Students')); ?></a></li>
                                <li class="nav-item"><a href="<?php echo e(route('students.promotion_manage')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.promotion_manage']) ? 'active' : ''); ?>"><?php echo e(__('Manage Promotions')); ?></a></li>
                            </ul>

                            </li>

                            
                            <li class="nav-item"><a href="<?php echo e(route('students.graduated')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.graduated' ]) ? 'active' : ''); ?>"><?php echo e(__('Students Graduated')); ?></a></li>
                                <?php endif; ?>

                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Qs::userIsTeamSA()): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['users.index', 'users.show', 'users.edit']) ? 'active' : ''); ?>"><i class="icon-users4"></i> <span> <?php echo e(__('Users')); ?></span></a>
                    </li>

                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('classes.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['classes.index','classes.edit']) ? 'active' : ''); ?>"><i class="icon-windows2"></i> <span> <?php echo e(__('Classes')); ?></span></a>
                    </li>

                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('dorms.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['dorms.index','dorms.edit']) ? 'active' : ''); ?>"><i class="icon-home9"></i> <span> <?php echo e(__('Dormitories')); ?></span></a>
                    </li>

                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('sections.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['sections.index','sections.edit',]) ? 'active' : ''); ?>"><i class="icon-fence"></i> <span><?php echo e(__('Sections')); ?></span></a>
                    </li>

                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjects.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['subjects.index','subjects.edit',]) ? 'active' : ''); ?>"><i class="icon-pin"></i> <span><?php echo e(__('Subjects')); ?></span></a>
                    </li>
                <?php endif; ?>

                
                <?php if(Qs::userIsTeamSAT()): ?>
                <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['exams.index', 'exams.edit', 'grades.index', 'grades.edit', 'marks.index', 'marks.manage', 'marks.bulk', 'marks.tabulation', 'marks.show', 'marks.batch_fix',]) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                    <a href="#" class="nav-link"><i class="icon-books"></i> <span> <?php echo e(__('Exams')); ?></span></a>

                    <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Manage Exams')); ?>">
                        <?php if(Qs::userIsTeamSA()): ?>

                        
                            <li class="nav-item">
                                <a href="<?php echo e(route('exams.index')); ?>"
                                   class="nav-link <?php echo e((Route::is('exams.index')) ? 'active' : ''); ?>"><?php echo e(__('Exam List')); ?></a>
                            </li>

                            
                            <li class="nav-item">
                                    <a href="<?php echo e(route('grades.index')); ?>"
                                       class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['grades.index', 'grades.edit']) ? 'active' : ''); ?>"><?php echo e(__('Grades')); ?></a>
                            </li>

                            
                            <li class="nav-item">
                                <a href="<?php echo e(route('marks.tabulation')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['marks.tabulation']) ? 'active' : ''); ?>"><?php echo e(__('Tabulation Sheet')); ?></a>
                            </li>

                            
                            <li class="nav-item">
                                <a href="<?php echo e(route('marks.batch_fix')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['marks.batch_fix']) ? 'active' : ''); ?>"><?php echo e(__('Batch Fix')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if(Qs::userIsTeamSAT()): ?>
                            
                            <li class="nav-item">
                                <a href="<?php echo e(route('marks.index')); ?>"
                                   class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['marks.index']) ? 'active' : ''); ?>"><?php echo e(__('Marks')); ?></a>
                            </li>

                            
                            <li class="nav-item">
                                <a href="<?php echo e(route('marks.bulk')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['marks.bulk', 'marks.show']) ? 'active' : ''); ?>"><?php echo e(__('Marksheet')); ?></a>
                            </li>

                            <?php endif; ?>

                    </ul>
                </li>
                <?php endif; ?>


                

                <?php if(Qs::userIsTeamSA()): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('academic_years.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['academic_years.index', 'academic_years.edit']) ? 'active' : ''); ?>"><i class="icon-calendar52"></i> <span><?php echo e(__('Academic Years (BS)')); ?></span></a>
                    </li>

                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('holidays.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['holidays.index', 'holidays.edit']) ? 'active' : ''); ?>"><i class="icon-calendar"></i> <span><?php echo e(__('Holiday Calendar')); ?></span></a>
                    </li>

                    
                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['books.index', 'books.edit', 'books.show', 'books.circulations', 'books.categories', 'book_requests.index']) ? 'nav-item-expanded nav-item-open' : ''); ?>">
                        <a href="#" class="nav-link"><i class="icon-books"></i> <span><?php echo e(__('Library')); ?></span></a>
                        <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Library')); ?>">
                            <li class="nav-item">
                                <a href="<?php echo e(route('books.index')); ?>" class="nav-link <?php echo e(Route::is('books.index') ? 'active' : ''); ?>"><?php echo e(__('Books & Inventory')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('books.circulations')); ?>" class="nav-link <?php echo e(Route::is('books.circulations') ? 'active' : ''); ?>"><?php echo e(__('Issue & Return')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('book_requests.index')); ?>" class="nav-link <?php echo e(Route::is('book_requests.index') ? 'active' : ''); ?>"><?php echo e(__('Book Requests')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('books.categories')); ?>" class="nav-link <?php echo e(Route::is('books.categories') ? 'active' : ''); ?>"><?php echo e(__('Book Categories')); ?></a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <?php if(Qs::userIsTeamSAT()): ?>
                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['attendance.index', 'attendance.monthly', 'attendance.class_report', 'staff_attendance.index', 'staff_attendance.monthly']) ? 'nav-item-expanded nav-item-open' : ''); ?>">
                        <a href="#" class="nav-link"><i class="icon-user-check"></i> <span><?php echo e(__('Attendance')); ?></span></a>
                        <ul class="nav nav-group-sub" data-submenu-title="<?php echo e(__('Attendance')); ?>">
                            <li class="nav-item">
                                <a href="<?php echo e(route('attendance.index')); ?>" class="nav-link <?php echo e(Route::is('attendance.index') ? 'active' : ''); ?>"><?php echo e(__('Daily Student Attendance')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('attendance.monthly')); ?>" class="nav-link <?php echo e(Route::is('attendance.monthly') ? 'active' : ''); ?>"><?php echo e(__('Monthly Attendance Sheet')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('attendance.class_report')); ?>" class="nav-link <?php echo e(Route::is('attendance.class_report') ? 'active' : ''); ?>"><?php echo e(__('Class Comparison Report')); ?></a>
                            </li>
                            <?php if(Qs::userIsTeamSA()): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('staff_attendance.index')); ?>" class="nav-link <?php echo e(Route::is('staff_attendance.index') ? 'active' : ''); ?>"><?php echo e(__('Daily Staff Attendance')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('staff_attendance.monthly')); ?>" class="nav-link <?php echo e(Route::is('staff_attendance.monthly') ? 'active' : ''); ?>"><?php echo e(__('Staff Monthly Summary')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('notices.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['notices.index', 'notices.show', 'notices.create', 'notices.edit']) ? 'active' : ''); ?>">
                        <i class="icon-newspaper"></i> <span><?php echo e(__('Noticeboard')); ?></span>
                    </a>
                </li>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('study_materials.index')); ?>" class="nav-link <?php echo e(Route::is('study_materials.index') ? 'active' : ''); ?>">
                        <i class="icon-file-text2"></i> <span><?php echo e(__('Study Materials')); ?></span>
                    </a>
                </li>

                <?php echo $__env->make('pages.'.Qs::getUserType().'.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('my_account')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['my_account']) ? 'active' : ''); ?>"><i class="icon-user"></i> <span><?php echo e(__('My Account')); ?></span></a>
                </li>

                </ul>
            </div>
        </div>
</div>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\partials\menu.blade.php ENDPATH**/ ?>