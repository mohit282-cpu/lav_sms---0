<?php $__env->startSection('page_title', __('Monthly Staff Attendance Summary (BS)')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card d-print-none">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('Monthly Staff Attendance Summary (Bikram Sambat)')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <form method="get" action="<?php echo e(route('staff_attendance.monthly')); ?>">
                <div class="row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo e(__('BS Year')); ?>: <span class="text-danger">*</span></label>
                        <input type="number" name="year_bs" value="<?php echo e($selected_year); ?>" min="2000" max="2090" required class="form-control" placeholder="2083">
                    </div>

                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo e(__('BS Month')); ?>: <span class="text-danger">*</span></label>
                        <select name="month_bs" required class="form-control select">
                            <?php $__currentLoopData = App\Services\BikramSambatService::MONTHS_NE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mIdx => $mName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(($selected_month == $mIdx) ? 'selected' : ''); ?> value="<?php echo e($mIdx); ?>">
                                    <?php echo e($mName); ?> (<?php echo e(App\Services\BikramSambatService::MONTHS_EN[$mIdx]); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3 pt-md-4">
                        <button type="submit" class="btn btn-primary btn-block"><i class="icon-filter3 mr-1"></i> <?php echo e(__('Generate Sheet')); ?></button>
                    </div>

                    <div class="col-md-3 pt-md-4">
                        <button type="button" class="btn btn-outline-secondary btn-block" onclick="window.print()"><i class="icon-printer mr-1"></i> <?php echo e(__('Print Sheet')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header header-elements-inline">
            <div>
                <h6 class="card-title font-weight-bold">
                    <?php echo e($month_name); ?> (<?php echo e($month_name_en); ?>) <?php echo e($selected_year); ?> BS - <?php echo e(__('Staff Attendance Sheet')); ?>

                </h6>
                <span class="text-muted font-size-sm">
                    <?php echo e(__('Days in month')); ?>: <?php echo e($days_in_month); ?> | <?php echo e(__('P = Present, A = Absent, L = Late, V = Leave, H = Half Day')); ?>

                </span>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-sm text-center font-size-sm mb-0">
                    <thead class="bg-light">
                    <tr>
                        <th rowspan="2" style="width: 40px;">#</th>
                        <th rowspan="2" class="text-left" style="min-width: 140px;"><?php echo e(__('Staff Name')); ?></th>
                        <th rowspan="2" style="width: 100px;"><?php echo e(__('Role')); ?></th>
                        <?php for($d = 1; $d <= $days_in_month; $d++): ?>
                            <?php
                                $dInfo = $dates[$d];
                                $isOff = ($dInfo['is_holiday'] || $dInfo['is_saturday']);
                            ?>
                            <th style="<?php echo e($isOff ? 'background-color: #f1f1f1; color: #dc3545;' : ''); ?>" title="<?php echo e($dInfo['is_holiday'] ? $dInfo['holiday_title'] : ($dInfo['is_saturday'] ? 'Saturday' : '')); ?>">
                                <?php echo e($d); ?>

                            </th>
                        <?php endfor; ?>
                        <th colspan="4" class="bg-secondary text-white"><?php echo e(__('Summary')); ?></th>
                    </tr>
                    <tr>
                        <?php for($d = 1; $d <= $days_in_month; $d++): ?>
                            <?php
                                $dInfo = $dates[$d];
                                $isOff = ($dInfo['is_holiday'] || $dInfo['is_saturday']);
                            ?>
                            <th style="font-size: 10px; <?php echo e($isOff ? 'background-color: #f1f1f1; color: #dc3545;' : ''); ?>">
                                <?php echo e($dInfo['is_saturday'] ? 'शनि' : ''); ?>

                            </th>
                        <?php endfor; ?>
                        <th class="bg-success text-white" title="Present">P</th>
                        <th class="bg-danger text-white" title="Absent">A</th>
                        <th class="bg-warning text-dark" title="Late">L</th>
                        <th class="bg-info text-white" title="Percentage">%</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $matrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="text-left font-weight-semibold text-nowrap"><?php echo e($row['name']); ?></td>
                            <td><span class="badge badge-light border"><?php echo e($row['role']); ?></span></td>
                            <?php for($d = 1; $d <= $days_in_month; $d++): ?>
                                <?php
                                    $dInfo = $dates[$d];
                                    $isOff = ($dInfo['is_holiday'] || $dInfo['is_saturday']);
                                    $status = $row['days'][$d];
                                ?>
                                <td style="<?php echo e($isOff ? 'background-color: #f9f9f9;' : ''); ?>">
                                    <?php if($status === 'present'): ?>
                                        <span class="text-success font-weight-bold">P</span>
                                    <?php elseif($status === 'absent'): ?>
                                        <span class="text-danger font-weight-bold">A</span>
                                    <?php elseif($status === 'late'): ?>
                                        <span class="text-warning font-weight-bold">L</span>
                                    <?php elseif($status === 'leave'): ?>
                                        <span class="text-info font-weight-bold">V</span>
                                    <?php elseif($status === 'half_day'): ?>
                                        <span class="text-secondary font-weight-bold">H</span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                            <td class="font-weight-bold text-success"><?php echo e($row['stats']['present']); ?></td>
                            <td class="font-weight-bold text-danger"><?php echo e($row['stats']['absent']); ?></td>
                            <td class="font-weight-bold text-warning"><?php echo e($row['stats']['late']); ?></td>
                            <td class="font-weight-bold <?php echo e($row['stats']['percentage'] >= 75 ? 'text-success' : 'text-danger'); ?>">
                                <?php echo e($row['stats']['percentage']); ?>%
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e($days_in_month + 7); ?>" class="text-center py-3 text-muted">
                                <?php echo e(__('No staff members found.')); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\staff_attendance\monthly.blade.php ENDPATH**/ ?>