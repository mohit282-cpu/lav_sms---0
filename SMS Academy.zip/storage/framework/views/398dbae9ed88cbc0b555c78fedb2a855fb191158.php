<?php $__env->startSection('page_title', __('Library Catalogue')); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-semibold"><i class="icon-search4 mr-2"></i><?php echo e(__('Search Library Catalogue')); ?></h6>
            <div class="header-elements">
                <a href="<?php echo e(route('book_requests.my_requests')); ?>" class="btn btn-outline-primary btn-sm font-weight-bold">
                    <i class="icon-books mr-1"></i> <?php echo e(__('My Borrowed & Requested Books')); ?>

                </a>
            </div>
        </div>

        <div class="card-body">
            <form method="get" action="<?php echo e(route('books.catalogue')); ?>">
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Keyword / Title / Author / ISBN')); ?></label>
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="<?php echo e(__('Search by title, author name, or ISBN...')); ?>">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Category')); ?></label>
                            <select name="category_id" class="form-control select">
                                <option value=""><?php echo e(__('All Categories')); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Grade / Class')); ?></label>
                            <select name="my_class_id" class="form-control select">
                                <option value=""><?php echo e(__('All Classes')); ?></option>
                                <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(request('my_class_id') == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2 d-flex align-items-end">
                        <div class="form-group w-100">
                            <button type="submit" class="btn btn-primary btn-block font-weight-bold">
                                <i class="icon-filter3 mr-1"></i> <?php echo e(__('Filter')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-semibold"><?php echo e(__('Books in Library')); ?></h6>
            <span class="badge badge-light badge-striped font-size-sm"><?php echo e(count($books)); ?> <?php echo e(__('Titles Found')); ?></span>
        </div>

        <div class="card-body">
            <?php if(count($books) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Book Title')); ?></th>
                            <th><?php echo e(__('Author')); ?></th>
                            <th><?php echo e(__('Category')); ?></th>
                            <th><?php echo e(__('Class')); ?></th>
                            <th><?php echo e(__('Shelf Location')); ?></th>
                            <th><?php echo e(__('Availability')); ?></th>
                            <th class="text-center"><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <a href="<?php echo e(route('books.show', $b->id)); ?>" class="font-weight-semibold">
                                        <?php echo e($b->name); ?>

                                    </a>
                                    <?php if($b->isbn): ?>
                                        <div class="text-muted font-size-xs">ISBN: <?php echo e($b->isbn); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($b->author ?: '-'); ?></td>
                                <td>
                                    <?php if($b->category): ?>
                                        <span class="badge badge-light border-left-primary badge-striped"><?php echo e($b->category->name); ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($b->my_class ? $b->my_class->name : __('General')); ?></td>
                                <td><span class="badge badge-info"><?php echo e($b->location ?: '-'); ?></span></td>
                                <td>
                                    <?php if($b->available_copies > 0): ?>
                                        <span class="badge badge-success font-weight-semibold">
                                            <?php echo e($b->available_copies); ?> <?php echo e(__('Available')); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><?php echo e(__('Out of Stock')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('books.show', $b->id)); ?>" class="btn btn-sm btn-outline-primary mr-1">
                                            <i class="icon-eye"></i>
                                        </a>

                                        <?php if($b->available_copies > 0): ?>
                                            <form method="post" action="<?php echo e(route('book_requests.store')); ?>" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="book_id" value="<?php echo e($b->id); ?>">
                                                <button type="submit" class="btn btn-sm btn-success font-weight-bold" onclick="return confirm('<?php echo e(__('Request to borrow: :title?', ['title' => $b->name])); ?>')">
                                                    <i class="icon-paperplane mr-1"></i> <?php echo e(__('Request')); ?>

                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-light text-muted" disabled>
                                                <?php echo e(__('Unavailable')); ?>

                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center text-muted py-5">
                    <i class="icon-books icon-3x mb-3 text-muted"></i>
                    <h5><?php echo e(__('No Books Found')); ?></h5>
                    <p class="text-muted"><?php echo e(__('Try adjusting your search criteria or clearing filters.')); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\catalogue.blade.php ENDPATH**/ ?>