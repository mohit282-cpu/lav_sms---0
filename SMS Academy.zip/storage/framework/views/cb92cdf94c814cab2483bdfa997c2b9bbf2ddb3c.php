<?php $__env->startSection('page_title', __('Manage Book Categories')); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        
        <div class="col-md-7">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-semibold"><i class="icon-folder-open mr-2"></i><?php echo e(__('Book Categories')); ?></h6>
                    <?php echo Qs::getPanelOptions(); ?>

                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Category Name')); ?></th>
                                <th><?php echo e(__('Slug')); ?></th>
                                <th><?php echo e(__('Books Count')); ?></th>
                                <th><?php echo e(__('Description')); ?></th>
                                <th class="text-center"><?php echo e(__('Action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="font-weight-semibold text-primary"><?php echo e($cat->name); ?></td>
                                    <td><code><?php echo e($cat->slug); ?></code></td>
                                    <td>
                                        <span class="badge badge-primary font-weight-bold">
                                            <?php echo e($cat->books_count ?? count($cat->books ?? [])); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($cat->description ?: '-'); ?></td>
                                    <td class="text-center">
                                        <?php if(($cat->books_count ?? count($cat->books ?? [])) == 0): ?>
                                            <a id="del-cat-<?php echo e($cat->id); ?>" onclick="confirmDelete(this.id)" href="#" class="btn btn-sm btn-outline-danger">
                                                <i class="icon-trash"></i>
                                            </a>
                                            <form method="post" id="item-delete-del-cat-<?php echo e($cat->id); ?>" action="<?php echo e(route('books.categories.destroy', $cat->id)); ?>" class="hidden">
                                                <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            </form>
                                        <?php else: ?>
                                            <span class="badge badge-light text-muted" title="<?php echo e(__('Protected: Has books assigned')); ?>">
                                                <i class="icon-lock2"></i> <?php echo e(__('In use')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-md-5">
            <div class="card">
                <div class="card-header header-elements-inline bg-light">
                    <h6 class="card-title font-weight-semibold text-primary"><i class="icon-plus-circle2 mr-2"></i><?php echo e(__('Add New Category')); ?></h6>
                </div>

                <div class="card-body">
                    <form method="post" action="<?php echo e(route('books.categories.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Category Name')); ?> <span class="text-danger">*</span></label>
                            <input name="name" value="<?php echo e(old('name')); ?>" required type="text" class="form-control" placeholder="<?php echo e(__('e.g. Science & Technology')); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Description (Optional)')); ?></label>
                            <textarea name="description" rows="3" class="form-control" placeholder="<?php echo e(__('Optional notes or classification details...')); ?>"><?php echo e(old('description')); ?></textarea>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary font-weight-bold">
                                <i class="icon-check mr-2"></i><?php echo e(__('Save Category')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/pages/support_team/books/categories.blade.php ENDPATH**/ ?>