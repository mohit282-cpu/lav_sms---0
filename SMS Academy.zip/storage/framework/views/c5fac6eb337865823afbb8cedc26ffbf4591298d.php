<?php $__env->startSection('page_title', __('Book Details: :name', ['name' => $book->name])); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-semibold"><?php echo e(__('Book Profile')); ?></h6>
                    <span class="badge <?php echo e($book->available_copies > 0 ? 'badge-success' : 'badge-danger'); ?>">
                        <?php echo e($book->available_copies > 0 ? __('Available') : __('Out of Stock')); ?>

                    </span>
                </div>

                <div class="card-body text-center">
                    <?php if($book->cover_image): ?>
                        <img src="<?php echo e(asset('storage/' . $book->cover_image)); ?>" class="img-fluid rounded mb-3 shadow" style="max-height: 240px;" alt="<?php echo e($book->name); ?>">
                    <?php else: ?>
                        <div class="p-4 bg-light rounded mb-3 border">
                            <i class="icon-book icon-4x text-muted opacity-50"></i>
                        </div>
                    <?php endif; ?>

                    <h5 class="font-weight-semibold mb-1"><?php echo e($book->name); ?></h5>
                    <p class="text-muted mb-3"><?php echo e($book->author ?: __('Author Unknown')); ?></p>

                    <div class="d-flex justify-content-center mb-3">
                        <?php if(Qs::userIsTeamLibrary()): ?>
                            <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-primary btn-sm mr-2">
                                <i class="icon-pencil mr-1"></i> <?php echo e(__('Edit Book')); ?>

                            </a>
                            <?php if($book->available_copies > 0): ?>
                                <a href="<?php echo e(route('books.circulations')); ?>?book_id=<?php echo e($book->id); ?>" class="btn btn-success btn-sm">
                                    <i class="icon-reading mr-1"></i> <?php echo e(__('Issue Book')); ?>

                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($book->available_copies > 0): ?>
                                <form method="post" action="<?php echo e(route('book_requests.store')); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="icon-paperplane mr-1"></i> <?php echo e(__('Request This Book')); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-borderless table-xs">
                        <tbody>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('ISBN')); ?>:</td>
                            <td class="text-right"><code><?php echo e($book->isbn ?: '-'); ?></code></td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Category')); ?>:</td>
                            <td class="text-right">
                                <?php if($book->category): ?>
                                    <span class="badge badge-light border-left-primary badge-striped"><?php echo e($book->category->name); ?></span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Publisher')); ?>:</td>
                            <td class="text-right"><?php echo e($book->publisher ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Edition')); ?>:</td>
                            <td class="text-right"><?php echo e($book->edition ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Pub. Year')); ?>:</td>
                            <td class="text-right"><?php echo e($book->publication_year ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Language')); ?>:</td>
                            <td class="text-right"><?php echo e($book->language ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Class / Grade')); ?>:</td>
                            <td class="text-right"><?php echo e($book->my_class ? $book->my_class->name : __('General')); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-semibold text-muted"><?php echo e(__('Shelf Location')); ?>:</td>
                            <td class="text-right"><span class="badge badge-info"><?php echo e($book->location ?: '-'); ?></span></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-semibold"><?php echo e(__('Inventory Status')); ?></h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo e(__('Total Copies')); ?></span>
                        <span class="font-weight-bold"><?php echo e($book->total_copies); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo e(__('Available for Loan')); ?></span>
                        <span class="font-weight-bold text-success"><?php echo e($book->available_copies); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <span><?php echo e(__('Currently Issued')); ?></span>
                        <span class="font-weight-bold text-danger"><?php echo e($book->issued_copies); ?></span>
                    </div>

                    <?php
                        $issuedPct = $book->total_copies > 0 ? round(($book->issued_copies / $book->total_copies) * 100) : 0;
                    ?>
                    <div class="progress mb-2" style="height: 10px;">
                        <div class="progress-bar bg-danger" style="width: <?php echo e($issuedPct); ?>%"></div>
                        <div class="progress-bar bg-success" style="width: <?php echo e(100 - $issuedPct); ?>%"></div>
                    </div>
                    <span class="font-size-xs text-muted"><?php echo e($issuedPct); ?>% <?php echo e(__('copies currently loaned out')); ?></span>
                </div>
            </div>
        </div>

        
        <div class="col-md-8">
            
            <?php if($book->description): ?>
                <div class="card">
                    <div class="card-header header-elements-inline">
                        <h6 class="card-title font-weight-semibold"><?php echo e(__('Description / Synopsis')); ?></h6>
                    </div>
                    <div class="card-body">
                        <p class="mb-0 text-muted"><?php echo e($book->description); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-semibold"><i class="icon-reading mr-2"></i><?php echo e(__('Current Active Loans')); ?></h6>
                    <span class="badge badge-primary"><?php echo e(count($book->activeLoans)); ?> <?php echo e(__('Active')); ?></span>
                </div>

                <div class="card-body">
                    <?php if(count($book->activeLoans) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('Borrower')); ?></th>
                                    <th><?php echo e(__('Role')); ?></th>
                                    <th><?php echo e(__('Issue Date (BS)')); ?></th>
                                    <th><?php echo e(__('Due Date (BS)')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <?php if(Qs::userIsTeamLibrary()): ?>
                                        <th class="text-center"><?php echo e(__('Action')); ?></th>
                                    <?php endif; ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $book->activeLoans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="font-weight-semibold"><?php echo e($loan->user ? $loan->user->name : '-'); ?></div>
                                            <div class="text-muted font-size-xs"><?php echo e($loan->user ? $loan->user->email : ''); ?></div>
                                        </td>
                                        <td><span class="badge badge-light"><?php echo e(ucfirst($loan->borrower_type)); ?></span></td>
                                        <td><?php echo e($loan->issue_date_bs ?: $loan->issue_date); ?></td>
                                        <td>
                                            <span class="<?php echo e($loan->is_overdue ? 'text-danger font-weight-bold' : ''); ?>">
                                                <?php echo e($loan->due_date_bs ?: $loan->due_date); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($loan->is_overdue): ?>
                                                <span class="badge badge-danger"><?php echo e(__('Overdue')); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-primary"><?php echo e(__('Issued')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <?php if(Qs::userIsTeamLibrary()): ?>
                                            <td class="text-center">
                                                <form method="post" action="<?php echo e(route('books.return_book', $loan->id)); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-success" onclick="return confirm('<?php echo e(__('Confirm returning this book to library inventory?')); ?>')">
                                                        <i class="icon-undo mr-1"></i> <?php echo e(__('Return')); ?>

                                                    </button>
                                                </form>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="icon-info22 icon-2x mb-2 text-muted"></i>
                            <p class="mb-0"><?php echo e(__('No copies of this book are currently on loan.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-semibold"><i class="icon-history mr-2"></i><?php echo e(__('Circulation History')); ?></h6>
                    <a href="<?php echo e(route('books.index')); ?>" class="btn btn-sm btn-outline-dark">
                        <i class="icon-arrow-left7 mr-1"></i> <?php echo e(__('Back to Inventory')); ?>

                    </a>
                </div>

                <div class="card-body">
                    <?php if(isset($recent_loans) && count($recent_loans) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('Borrower')); ?></th>
                                    <th><?php echo e(__('Issued')); ?></th>
                                    <th><?php echo e(__('Due Date')); ?></th>
                                    <th><?php echo e(__('Returned Date')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $recent_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($hist->user ? $hist->user->name : '-'); ?></td>
                                        <td><?php echo e($hist->issue_date_bs ?: $hist->issue_date); ?></td>
                                        <td><?php echo e($hist->due_date_bs ?: $hist->due_date); ?></td>
                                        <td><?php echo e($hist->return_date_bs ?: ($hist->return_date ?: '-')); ?></td>
                                        <td>
                                            <?php if($hist->status == 'returned'): ?>
                                                <span class="badge badge-success"><?php echo e(__('Returned')); ?></span>
                                            <?php elseif($hist->status == 'issued'): ?>
                                                <span class="badge badge-primary"><?php echo e(__('Issued')); ?></span>
                                            <?php elseif($hist->status == 'lost'): ?>
                                                <span class="badge badge-dark"><?php echo e(__('Lost')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-3">
                            <p class="mb-0"><?php echo e(__('No past loan records found for this book.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\show.blade.php ENDPATH**/ ?>