
<li class="nav-item">
    <a href="<?php echo e(route('tt.my_timetable')); ?>" class="nav-link <?php echo e(Route::is('tt.my_timetable') ? 'active' : ''); ?>"><i class="icon-calendar"></i> <span><?php echo e(__('My Teaching Timetable')); ?></span></a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('books.index')); ?>" class="nav-link <?php echo e(Route::is('books.index') ? 'active' : ''); ?>"><i class="icon-books"></i> <span><?php echo e(__('Library Catalogue')); ?></span></a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('book_requests.index')); ?>" class="nav-link <?php echo e(Route::is('book_requests.index') ? 'active' : ''); ?>"><i class="icon-list3"></i> <span><?php echo e(__('My Book Requests')); ?></span></a>
</li>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\teacher\menu.blade.php ENDPATH**/ ?>