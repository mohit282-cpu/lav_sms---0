<?php $__env->startSection('page_title', __('Holiday Calendar')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('School Holiday & Event Calendar (BS & AD)')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#calendar-view" class="nav-link active" data-toggle="tab"><i class="icon-calendar mr-1"></i> <?php echo e(__('Calendar View')); ?></a></li>
                <li class="nav-item"><a href="#all-holidays" class="nav-link" data-toggle="tab"><i class="icon-list mr-1"></i> <?php echo e(__('All Holidays & Events')); ?></a></li>
                <li class="nav-item"><a href="#new-holiday" class="nav-link" data-toggle="tab"><i class="icon-plus2 mr-1"></i> <?php echo e(__('Add Holiday / Event')); ?></a></li>
            </ul>

            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="calendar-view">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <span class="badge badge-danger p-2 mr-2"><i class="icon-primitive-dot"></i> <?php echo e(__('Public / School Holiday')); ?></span>
                            <span class="badge badge-warning p-2 mr-2 text-white"><i class="icon-primitive-dot"></i> <?php echo e(__('Examination Period')); ?></span>
                            <span class="badge badge-primary p-2 mr-2"><i class="icon-primitive-dot"></i> <?php echo e(__('Academic Event')); ?></span>
                            <span class="badge badge-success p-2 mr-2"><i class="icon-primitive-dot"></i> <?php echo e(__('Custom Working Day')); ?></span>
                        </div>
                    </div>
                    <div class="fullcalendar-basic" id="school-holiday-calendar"></div>
                </div>

                
                <div class="tab-pane fade" id="all-holidays">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Title')); ?></th>
                            <th><?php echo e(__('Title (Nepali)')); ?></th>
                            <th><?php echo e(__('Type')); ?></th>
                            <th><?php echo e(__('Dates (BS)')); ?></th>
                            <th><?php echo e(__('Dates (AD)')); ?></th>
                            <th><?php echo e(__('School Closure')); ?></th>
                            <th><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $holidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-semibold"><?php echo e($h->title); ?></td>
                                <td><?php echo e($h->title_ne ?: '-'); ?></td>
                                <td>
                                    <?php if($h->type === 'public_holiday'): ?>
                                        <span class="badge badge-danger"><?php echo e(__('Public Holiday')); ?></span>
                                    <?php elseif($h->type === 'school_holiday'): ?>
                                        <span class="badge badge-danger"><?php echo e(__('School Holiday')); ?></span>
                                    <?php elseif($h->type === 'exam_period'): ?>
                                        <span class="badge badge-warning text-white"><?php echo e(__('Exam Period')); ?></span>
                                    <?php elseif($h->type === 'academic_event'): ?>
                                        <span class="badge badge-primary"><?php echo e(__('Academic Event')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-success"><?php echo e(__('Working Day')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($h->start_date_bs); ?> <?php if($h->start_date_bs !== $h->end_date_bs): ?> - <?php echo e($h->end_date_bs); ?> <?php endif; ?> BS</td>
                                <td><?php echo e($h->start_date->format('Y-m-d')); ?> <?php if($h->start_date->format('Y-m-d') !== $h->end_date->format('Y-m-d')): ?> - <?php echo e($h->end_date->format('Y-m-d')); ?> <?php endif; ?></td>
                                <td>
                                    <?php if($h->is_closure): ?>
                                        <span class="badge badge-danger"><?php echo e(__('Closed')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-info"><?php echo e(__('Open')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <form method="post" action="<?php echo e(route('holidays.destroy', $h->id)); ?>" onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this event?')); ?>');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="icon-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="tab-pane fade" id="new-holiday">
                    <div class="row">
                        <div class="col-md-8">
                            <form method="post" action="<?php echo e(route('holidays.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Event Title (English)')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="title" value="<?php echo e(old('title')); ?>" required type="text" class="form-control" placeholder="e.g. Dashain Vacation">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Event Title (Nepali)')); ?>:</label>
                                    <div class="col-lg-9">
                                        <input name="title_ne" value="<?php echo e(old('title_ne')); ?>" type="text" class="form-control" placeholder="उदा: दशैं बिदा">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Event Type')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="type" required class="form-control select">
                                            <option value="public_holiday"><?php echo e(__('Public Holiday (सार्वजनिक बिदा)')); ?></option>
                                            <option value="school_holiday" selected><?php echo e(__('School Holiday (विद्यालय बिदा)')); ?></option>
                                            <option value="exam_period"><?php echo e(__('Examination Period (परीक्षा अवधि)')); ?></option>
                                            <option value="academic_event"><?php echo e(__('Academic Event / Celebration (शैक्षिक कार्यक्रम)')); ?></option>
                                            <option value="custom_working_day"><?php echo e(__('Custom Working Day (कार्य दिन)')); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Start Date (BS)')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="start_date_bs" value="<?php echo e(old('start_date_bs', '2083-07-07')); ?>" required type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('End Date (BS)')); ?>: <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input name="end_date_bs" value="<?php echo e(old('end_date_bs', '2083-07-07')); ?>" required type="text" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('Description')); ?>:</label>
                                    <div class="col-lg-9">
                                        <textarea name="description" class="form-control" rows="3" placeholder="<?php echo e(__('Optional details')); ?>"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold"><?php echo e(__('School Closure')); ?>:</label>
                                    <div class="col-lg-9">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="is_closure" value="1" class="form-check-input-styled" checked data-fouc>
                                                <?php echo e(__('School remains closed on this day/period')); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Add Event / Holiday')); ?> <i class="icon-paperplane ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        if ($('#school-holiday-calendar').length) {
            $('#school-holiday-calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                events: '<?php echo e(route("calendar.events")); ?>',
                editable: false,
                eventLimit: true
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\holidays\index.blade.php ENDPATH**/ ?>