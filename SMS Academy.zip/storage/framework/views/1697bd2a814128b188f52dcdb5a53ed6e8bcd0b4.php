
<?php $__env->startSection('page_title', 'Generate Pins'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title"><i class="icon-alarm mr-2"></i> Generate Pins</h5>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <form method="post" action="<?php echo e(route('pins.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="pin_count" class="font-weight-bold col-form-label">Generate Pins (Enter Amount of Pins you Need) </label>
                            <input class="form-control form-control-lg" placeholder="Enter Number Between 10 and 500" required name="pin_count" type="text">
                        </div>

                        <div class="text-center mt-2">
                            <button type="submit" class="btn btn-primary btn-lg">Submit <i class="icon-paperplane ml-2"></i></button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\pins\create.blade.php ENDPATH**/ ?>