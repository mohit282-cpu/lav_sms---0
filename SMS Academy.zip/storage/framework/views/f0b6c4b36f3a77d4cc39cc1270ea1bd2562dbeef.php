<?php $__env->startSection('page_title', __('Student Attendance History') . ' - ' . $sr->user->name); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <img src="<?php echo e($sr->user->photo); ?>" class="rounded-circle mb-2" style="width: 80px; height: 80px;" alt="Photo">
                    <h5 class="font-weight-bold mb-1"><?php echo e($sr->user->name); ?></h5>
                    <p class="text-muted mb-2"><?php echo e(__('Adm No')); ?>: <strong><?php echo e($sr->adm_no); ?></strong></p>
                    <span class="badge badge-primary p-2"><?php echo e($sr->my_class->name); ?> <?php echo e($sr->section ? '('.$sr->section->name.')' : ''); ?></span>
                    <span class="badge badge-secondary p-2"><?php echo e($sr->session); ?></span>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-bold"><?php echo e(__('Attendance Summary & Analytics')); ?></h6>
                    <button class="btn btn-sm btn-outline-secondary" onclick="window.print()"><i class="icon-printer mr-1"></i> <?php echo e(__('Print History')); ?></button>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4 col-md-2 mb-2">
                            <div class="border rounded p-2">
                                <span class="text-muted font-size-sm"><?php echo e(__('Total Days')); ?></span>
                                <h4 class="font-weight-bold mb-0"><?php echo e($stats['total_days']); ?></h4>
                            </div>
                        </div>
                        <div class="col-4 col-md-2 mb-2">
                            <div class="border rounded p-2 bg-light">
                                <span class="text-success font-size-sm font-weight-bold"><?php echo e(__('Present')); ?></span>
                                <h4 class="font-weight-bold text-success mb-0"><?php echo e($stats['present']); ?></h4>
                            </div>
                        </div>
                        <div class="col-4 col-md-2 mb-2">
                            <div class="border rounded p-2 bg-light">
                                <span class="text-danger font-size-sm font-weight-bold"><?php echo e(__('Absent')); ?></span>
                                <h4 class="font-weight-bold text-danger mb-0"><?php echo e($stats['absent']); ?></h4>
                            </div>
                        </div>
                        <div class="col-4 col-md-2 mb-2">
                            <div class="border rounded p-2 bg-light">
                                <span class="text-warning font-size-sm font-weight-bold"><?php echo e(__('Late')); ?></span>
                                <h4 class="font-weight-bold text-warning mb-0"><?php echo e($stats['late']); ?></h4>
                            </div>
                        </div>
                        <div class="col-4 col-md-2 mb-2">
                            <div class="border rounded p-2 bg-light">
                                <span class="text-info font-size-sm font-weight-bold"><?php echo e(__('Leave')); ?></span>
                                <h4 class="font-weight-bold text-info mb-0"><?php echo e($stats['leave']); ?></h4>
                            </div>
                        </div>
                        <div class="col-4 col-md-2 mb-2">
                            <div class="border rounded p-2 <?php echo e($stats['percentage'] >= 75 ? 'bg-success text-white' : ($stats['percentage'] >= 60 ? 'bg-warning text-dark' : 'bg-danger text-white')); ?>">
                                <span class="font-size-sm font-weight-bold"><?php echo e(__('Percentage')); ?></span>
                                <h4 class="font-weight-bold mb-0"><?php echo e($stats['percentage']); ?>%</h4>
                            </div>
                        </div>
                    </div>

                    <?php if($stats['leave'] > 0): ?>
                        <div class="mt-2 text-muted font-size-sm">
                            <i class="icon-info22 mr-1"></i> <?php echo e(__('Excused Attendance Percentage (excluding approved leave): :pct%', ['pct' => $stats['excused_percentage']])); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card d-print-none">
        <div class="card-body">
            <form method="get" action="<?php echo e(route('attendance.student_history', $sr->id)); ?>">
                <div class="row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo e(__('Start Date (BS)')); ?>:</label>
                        <input type="text" name="start_date_bs" value="<?php echo e($start_date_bs); ?>" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                    </div>
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo e(__('End Date (BS)')); ?>:</label>
                        <input type="text" name="end_date_bs" value="<?php echo e($end_date_bs); ?>" class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                    </div>
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo e(__('Status')); ?>:</label>
                        <select name="status" class="form-control select">
                            <option value=""><?php echo e(__('All Statuses')); ?></option>
                            <option <?php echo e($status_filter === 'present' ? 'selected' : ''); ?> value="present"><?php echo e(__('Present')); ?></option>
                            <option <?php echo e($status_filter === 'absent' ? 'selected' : ''); ?> value="absent"><?php echo e(__('Absent')); ?></option>
                            <option <?php echo e($status_filter === 'late' ? 'selected' : ''); ?> value="late"><?php echo e(__('Late')); ?></option>
                            <option <?php echo e($status_filter === 'leave' ? 'selected' : ''); ?> value="leave"><?php echo e(__('Leave')); ?></option>
                            <option <?php echo e($status_filter === 'half_day' ? 'selected' : ''); ?> value="half_day"><?php echo e(__('Half Day')); ?></option>
                        </select>
                    </div>
                    <div class="col-md-3 pt-md-4">
                        <button type="submit" class="btn btn-primary btn-block"><i class="icon-filter3 mr-1"></i> <?php echo e(__('Apply Filter')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-bold"><?php echo e(__('Attendance Log')); ?> (<?php echo e(count($records)); ?>)</h6>
        </div>
        <div class="card-body">
            <?php if(count($records) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Date (BS)')); ?></th>
                            <th><?php echo e(__('Date (AD)')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Remarks')); ?></th>
                            <th><?php echo e(__('Recorded At')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-bold"><?php echo e($rec->attendance_date_bs); ?> BS</td>
                                <td><?php echo e($rec->attendance_date ? $rec->attendance_date->format('Y-m-d (D)') : '-'); ?></td>
                                <td>
                                    <?php if($rec->status === 'present'): ?>
                                        <span class="badge badge-success p-2"><?php echo e(__('Present')); ?></span>
                                    <?php elseif($rec->status === 'absent'): ?>
                                        <span class="badge badge-danger p-2"><?php echo e(__('Absent')); ?></span>
                                    <?php elseif($rec->status === 'late'): ?>
                                        <span class="badge badge-warning p-2"><?php echo e(__('Late')); ?></span>
                                    <?php elseif($rec->status === 'leave'): ?>
                                        <span class="badge badge-info p-2"><?php echo e(__('Leave')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary p-2"><?php echo e(__('Half Day')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($rec->remarks ?: '-'); ?></td>
                                <td><?php echo e($rec->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info border-0">
                    <i class="icon-info22 mr-1"></i> <?php echo e(__('No attendance records found for this student matching the criteria.')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\attendance\student_history.blade.php ENDPATH**/ ?>