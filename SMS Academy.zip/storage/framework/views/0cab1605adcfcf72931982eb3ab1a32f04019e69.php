<?php $__env->startSection('page_title', __('Manage Book Requests')); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-6 col-xl-4">
            <div class="card card-body bg-warning-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['pending'] ?? count($pending_requests)); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Pending Book Requests')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-hour-glass2 icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-4">
            <div class="card card-body bg-success-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['approved'] ?? count($approved_requests)); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Approved (Ready to Issue)')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-checkmark4 icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-4">
            <div class="card card-body bg-danger-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['rejected'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Rejected / Cancelled')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-cross2 icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-semibold"><i class="icon-list3 mr-2"></i><?php echo e(__('Book Requests Management')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item">
                    <a href="#pending-req" class="nav-link active" data-toggle="tab">
                        <i class="icon-hour-glass2 mr-2 text-warning"></i>
                        <?php echo e(__('Pending Requests')); ?> (<?php echo e(count($pending_requests)); ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#approved-req" class="nav-link" data-toggle="tab">
                        <i class="icon-checkmark4 mr-2 text-success"></i>
                        <?php echo e(__('Approved (Awaiting Collection)')); ?> (<?php echo e(count($approved_requests)); ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#past-req" class="nav-link" data-toggle="tab">
                        <i class="icon-history mr-2"></i>
                        <?php echo e(__('Archived / Rejected')); ?> (<?php echo e(count($past_requests)); ?>)
                    </a>
                </li>
            </ul>

            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="pending-req">
                    <?php if(count($pending_requests) > 0): ?>
                        <table class="table datatable-button-html5-columns table-striped table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Book Title')); ?></th>
                                <th><?php echo e(__('Requester')); ?></th>
                                <th><?php echo e(__('Role')); ?></th>
                                <th><?php echo e(__('Available Stock')); ?></th>
                                <th><?php echo e(__('Request Date')); ?></th>
                                <th class="text-center"><?php echo e(__('Action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $pending_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('books.show', $req->book_id)); ?>" class="font-weight-semibold">
                                            <?php echo e($req->book ? $req->book->name : '-'); ?>

                                        </a>
                                        <?php if($req->book && $req->book->category): ?>
                                            <div class="text-muted font-size-xs"><?php echo e($req->book->category->name); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="font-weight-semibold"><?php echo e($req->user ? $req->user->name : '-'); ?></div>
                                        <div class="text-muted font-size-xs"><?php echo e($req->user ? $req->user->email : ''); ?></div>
                                    </td>
                                    <td><span class="badge badge-light border-left-info badge-striped"><?php echo e(ucfirst($req->borrower_type)); ?></span></td>
                                    <td>
                                        <?php if($req->book): ?>
                                            <span class="badge <?php echo e($req->book->available_copies > 0 ? 'badge-success' : 'badge-danger'); ?>">
                                                <?php echo e($req->book->available_copies); ?> <?php echo e(__('Available')); ?>

                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($req->request_date_bs ?: $req->created_at->format('Y-m-d')); ?></td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <form method="post" action="<?php echo e(route('book_requests.approve', $req->id)); ?>" class="d-inline mr-1">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-success font-weight-bold" <?php echo e(($req->book && $req->book->available_copies == 0) ? 'disabled' : ''); ?>>
                                                    <i class="icon-checkmark mr-1"></i> <?php echo e(__('Approve')); ?>

                                                </button>
                                            </form>
                                            <form method="post" action="<?php echo e(route('book_requests.reject', $req->id)); ?>" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('<?php echo e(__('Reject this book request?')); ?>')">
                                                    <i class="icon-cross2 mr-1"></i> <?php echo e(__('Reject')); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="icon-checkmark-circle icon-2x mb-2 text-success"></i>
                            <p class="mb-0"><?php echo e(__('No pending book requests at this moment.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="tab-pane fade" id="approved-req">
                    <?php if(count($approved_requests) > 0): ?>
                        <table class="table datatable-button-html5-columns table-striped table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Book Title')); ?></th>
                                <th><?php echo e(__('Requester')); ?></th>
                                <th><?php echo e(__('Approved By')); ?></th>
                                <th><?php echo e(__('Approved Date')); ?></th>
                                <th class="text-center"><?php echo e(__('Circulate')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $approved_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('books.show', $app->book_id)); ?>" class="font-weight-semibold">
                                            <?php echo e($app->book ? $app->book->name : '-'); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($app->user ? $app->user->name : '-'); ?></td>
                                    <td><?php echo e($app->approver ? $app->approver->name : '-'); ?></td>
                                    <td><?php echo e($app->updated_at->format('Y-m-d')); ?></td>
                                    <td class="text-center">
                                        <form method="post" action="<?php echo e(route('book_requests.issue_from_request', $app->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-primary font-weight-bold" onclick="return confirm('<?php echo e(__('Issue physical copy to the borrower now?')); ?>')">
                                                <i class="icon-reading mr-1"></i> <?php echo e(__('Issue to Borrower')); ?>

                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <p class="mb-0"><?php echo e(__('No approved requests waiting for collection.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="tab-pane fade" id="past-req">
                    <table class="table datatable-button-html5-columns table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Book Title')); ?></th>
                            <th><?php echo e(__('Requester')); ?></th>
                            <th><?php echo e(__('Requested On')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $past_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $past): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($past->book ? $past->book->name : '-'); ?></td>
                                <td><?php echo e($past->user ? $past->user->name : '-'); ?></td>
                                <td><?php echo e($past->request_date_bs ?: $past->created_at->format('Y-m-d')); ?></td>
                                <td>
                                    <?php if($past->status == 'issued'): ?>
                                        <span class="badge badge-success"><?php echo e(__('Issued / Fulfilled')); ?></span>
                                    <?php elseif($past->status == 'rejected'): ?>
                                        <span class="badge badge-danger"><?php echo e(__('Rejected')); ?></span>
                                    <?php elseif($past->status == 'cancelled'): ?>
                                        <span class="badge badge-secondary"><?php echo e(__('Cancelled by User')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\requests.blade.php ENDPATH**/ ?>