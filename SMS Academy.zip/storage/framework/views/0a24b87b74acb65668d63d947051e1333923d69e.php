<?php $__env->startSection('page_title', $notice->title); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header header-elements-inline">
        <h5 class="card-title font-weight-bold"><?php echo e($notice->title); ?></h5>
        <div class="header-elements">
            <a href="<?php echo e(route('notices.index')); ?>" class="btn btn-outline-secondary btn-sm"><i class="icon-arrow-left52 mr-1"></i><?php echo e(__('Back to Notices')); ?></a>
            <?php if(Qs::userIsTeamSA()): ?>
                <a href="<?php echo e(route('notices.edit', $notice->id)); ?>" class="btn btn-outline-primary btn-sm ml-2"><i class="icon-pencil mr-1"></i><?php echo e(__('Edit')); ?></a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-body">
        <div class="d-flex flex-wrap text-muted font-size-sm border-bottom pb-2 mb-3">
            <span class="mr-3"><i class="icon-calendar mr-1"></i> <?php echo e(__('Posted')); ?>: <?php echo e($notice->notice_date_bs ? $notice->notice_date_bs . ' BS' : $notice->notice_date->format('Y-m-d')); ?></span>
            <?php if($notice->expiry_date): ?>
                <span class="mr-3"><i class="icon-calendar52 mr-1"></i> <?php echo e(__('Expires')); ?>: <?php echo e($notice->expiry_date_bs ? $notice->expiry_date_bs . ' BS' : $notice->expiry_date->format('Y-m-d')); ?></span>
            <?php endif; ?>
            <?php if($notice->creator): ?>
                <span class="mr-3"><i class="icon-user mr-1"></i> <?php echo e(__('Author')); ?>: <?php echo e($notice->creator->name); ?></span>
            <?php endif; ?>
            <span class="mr-3"><i class="icon-eye mr-1"></i> <?php echo e(__('Audience')); ?>: <?php echo e(ucfirst($notice->role_visibility ?? 'All')); ?></span>
            <?php if($notice->my_class): ?>
                <span class="mr-3"><i class="icon-graduation2 mr-1"></i> <?php echo e(__('Class')); ?>: <?php echo e($notice->my_class->name); ?></span>
            <?php endif; ?>
        </div>

        <div class="content-group text-dark" style="font-size: 1.05rem; line-height: 1.7; white-space: pre-wrap;"><?php echo e($notice->content); ?></div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/pages/support_team/notices/show.blade.php ENDPATH**/ ?>