
<?php $__env->startSection('page_title', 'My Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h2>WELCOME <?php echo e(Auth::user()->name); ?>. This is your DASHBOARD</h2>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\admin\dashboard.blade.php ENDPATH**/ ?>