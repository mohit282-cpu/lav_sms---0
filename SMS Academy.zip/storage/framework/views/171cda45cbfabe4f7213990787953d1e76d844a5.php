
<table style="width:100%; border-collapse:collapse; margin-bottom: 10px; font-size: 14px;">
    <tbody>
    <tr>
        <td><strong><?php echo e(__('NAME')); ?>:</strong> <?php echo e(strtoupper($sr->user->name)); ?></td>
        <td><strong><?php echo e(__('ADM / ROLL NO')); ?>:</strong> <?php echo e($sr->adm_no); ?></td>
        <td><strong><?php echo e(__('CLASS')); ?>:</strong> <?php echo e(strtoupper($my_class->name)); ?> <?php echo e($sr->section->name ?? ''); ?></td>
    </tr>
    <tr>
        <td><strong><?php echo e(__('EXAMINATION')); ?>:</strong> <?php echo e(strtoupper($ex->name)); ?></td>
        <td><strong><?php echo e(__('ACADEMIC YEAR')); ?>:</strong> <?php echo e($ex->year); ?></td>
        <td><strong><?php echo e(__('DATE OF BIRTH')); ?>:</strong> <?php echo e(App\Helpers\NepaliHelper::formatDualDate($sr->user->dob) ?: '-'); ?></td>
    </tr>
    <?php if($ex->start_date_bs): ?>
    <tr>
        <td colspan="3"><strong><?php echo e(__('EXAM PERIOD (BS)')); ?>:</strong> <?php echo e($ex->start_date_bs); ?> <?php if($ex->end_date_bs && $ex->end_date_bs !== $ex->start_date_bs): ?> - <?php echo e($ex->end_date_bs); ?> <?php endif; ?> BS</td>
    </tr>
    <?php endif; ?>
    </tbody>
</table>


<table style="width:100%; border-collapse:collapse; border: 1px solid #333; margin: 10px auto; font-size: 13px;" border="1" cellpadding="5">
    <thead>
    <tr style="background-color: #f2f2f2; text-align: center;">
        <th rowspan="2" style="text-align: left; width: 25%;"><?php echo e(__('SUBJECTS')); ?></th>
        <th rowspan="2" style="width: 8%;"><?php echo e(__('CREDIT HOUR')); ?></th>
        <th colspan="2"><?php echo e(__('OBTAINED MARKS')); ?></th>
        <th rowspan="2" style="width: 10%;"><?php echo e(__('FINAL MARKS')); ?></th>
        <th rowspan="2" style="width: 10%;"><?php echo e(__('GRADE POINT')); ?></th>
        <th rowspan="2" style="width: 10%;"><?php echo e(__('LETTER GRADE')); ?></th>
        <th rowspan="2" style="width: 15%;"><?php echo e(__('REMARKS')); ?></th>
    </tr>
    <tr style="background-color: #f8f9fa; text-align: center;">
        <th style="width: 11%;">TH</th>
        <th style="width: 11%;">PR</th>
    </tr>
    </thead>
    <tbody>
    <?php
        $totalCredits = 0;
        $totalWeightedGpa = 0;
    ?>
    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $mk = $marks->where('subject_id', $sub->id)->where('exam_id', $ex->id)->first();
            $cr = $sub->credit_hour ?: 4.0;
            $gpaPoint = $mk ? ($mk->gpa_point ?? 0.0) : 0.0;
            $totalCredits += $cr;
            $totalWeightedGpa += ($gpaPoint * $cr);
        ?>
        <tr>
            <td style="font-weight: bold; text-align: left;"><?php echo e($sub->name); ?></td>
            <td style="text-align: center;"><?php echo e(number_format($cr, 2)); ?></td>
            <td style="text-align: center;">
                <?php if($mk): ?>
                    <?php echo e($mk->is_absent ? 'ABS' : ($mk->is_exempt ? 'EXM' : ($mk->theory_mark ?? $mk->exm ?? '-'))); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td style="text-align: center;">
                <?php if($mk): ?>
                    <?php echo e($mk->is_absent ? 'ABS' : ($mk->is_exempt ? 'EXM' : ($mk->practical_mark ?? $mk->t1 ?? '-'))); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td style="text-align: center; font-weight: bold;">
                <?php if($mk): ?>
                    <?php echo e($mk->is_absent ? 'ABS' : ($mk->is_exempt ? 'EXM' : ($mk->total_mark ?? $mk->$tex ?? '-'))); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td style="text-align: center; font-weight: bold;">
                <?php echo e($mk && $mk->gpa_point !== null ? number_format($mk->gpa_point, 2) : '-'); ?>

            </td>
            <td style="text-align: center; font-weight: bold;">
                <?php echo e($mk ? ($mk->grade_name ?? ($mk->grade ? $mk->grade->name : '-')) : '-'); ?>

            </td>
            <td style="text-align: center;">
                <?php echo e($mk ? ($mk->remarks ?? ($mk->grade ? $mk->grade->remark : '-')) : '-'); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr style="background-color: #f2f2f2; font-weight: bold;">
        <td colspan="4" style="text-align: right; padding-right: 10px;"><?php echo e(__('GRADE POINT AVERAGE (GPA)')); ?>:</td>
        <td colspan="2" style="text-align: center; font-size: 16px; color: #1b0c80;">
            <?php echo e($exr->gpa ? number_format($exr->gpa, 2) : ($totalCredits > 0 ? number_format(round($totalWeightedGpa / $totalCredits, 2), 2) : '-')); ?>

        </td>
        <td colspan="2" style="text-align: center; font-size: 16px; color: <?php echo e(($exr->result_status === 'FAIL') ? '#d9534f' : '#28a745'); ?>;">
            <?php echo e($exr->grade ?: '-'); ?> (<?php echo e($exr->result_status ?: 'PASS'); ?>)
        </td>
    </tr>
    </tbody>
</table>


<div style="margin-top: 15px; margin-bottom: 10px;">
    <strong><?php echo e(__('GRADING SYSTEM (NEPAL STANDARD)')); ?>:</strong>
    <table style="width:100%; border-collapse:collapse; border: 1px solid #777; font-size: 11px; margin-top: 4px; text-align: center;" border="1" cellpadding="3">
        <tr style="background-color: #eee;">
            <th><?php echo e(__('Interval (%)')); ?></th>
            <th>90 - 100</th>
            <th>80 - 89.9</th>
            <th>70 - 79.9</th>
            <th>60 - 69.9</th>
            <th>50 - 59.9</th>
            <th>40 - 49.9</th>
            <th>35 - 39.9</th>
            <th>Below 35</th>
        </tr>
        <tr>
            <th><?php echo e(__('Grade')); ?></th>
            <td>A+</td><td>A</td><td>B+</td><td>B</td><td>C+</td><td>C</td><td>D</td><td>NG</td>
        </tr>
        <tr>
            <th><?php echo e(__('Grade Point')); ?></th>
            <td>4.0</td><td>3.6</td><td>3.2</td><td>2.8</td><td>2.4</td><td>2.0</td><td>1.6</td><td>0.0</td>
        </tr>
        <tr>
            <th><?php echo e(__('Description')); ?></th>
            <td>Outstanding</td><td>Excellent</td><td>Very Good</td><td>Good</td><td>Satisfactory</td><td>Acceptable</td><td>Basic</td><td>Non-Graded</td>
        </tr>
    </table>
</div>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\marks\print\sheet.blade.php ENDPATH**/ ?>