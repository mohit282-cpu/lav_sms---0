<?php $__env->startSection('page_title', __('Library Dashboard & Inventory')); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="row">
        <div class="col-sm-6 col-xl-2">
            <div class="card card-body bg-teal-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['total_titles'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Total Titles')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-books icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-2">
            <div class="card card-body bg-primary-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['total_copies'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Total Copies')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-stack2 icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-2">
            <div class="card card-body bg-success-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['available_copies'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Available Copies')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-checkmark4 icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-2">
            <div class="card card-body bg-indigo-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['issued_copies'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Issued Copies')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-reading icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-2">
            <div class="card card-body bg-danger-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['overdue_count'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Overdue Loans')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-alarm icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-2">
            <div class="card card-body bg-warning-400 has-bg-image">
                <div class="media">
                    <div class="media-body">
                        <h3 class="mb-0 font-weight-semibold"><?php echo e($stats['pending_requests'] ?? 0); ?></h3>
                        <span class="text-uppercase font-size-xs"><?php echo e(__('Pending Requests')); ?></span>
                    </div>
                    <div class="ml-3 align-self-center">
                        <i class="icon-hour-glass2 icon-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(($stats['overdue_count'] ?? 0) > 0): ?>
        <div class="alert alert-danger border-0 alert-dismissible">
            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
            <span class="font-weight-semibold"><i class="icon-warning2 mr-2"></i><?php echo e(__('Attention:')); ?></span>
            <?php echo e(__('There are :count overdue books currently unreturned.', ['count' => $stats['overdue_count']])); ?>

            <a href="<?php echo e(route('books.circulations')); ?>#overdue-loans" class="alert-link ml-2 font-weight-bold"><?php echo e(__('View Overdue Circulations')); ?> &rarr;</a>
        </div>
    <?php endif; ?>

    
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-semibold"><i class="icon-books mr-2"></i><?php echo e(__('Manage Library Books')); ?></h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item">
                    <a href="#all-books" class="nav-link active" data-toggle="tab">
                        <i class="icon-list mr-2"></i><?php echo e(__('Book Catalogue')); ?> (<?php echo e(count($books)); ?>)
                    </a>
                </li>
                <?php if(Qs::userIsTeamLibrary()): ?>
                    <li class="nav-item">
                        <a href="#new-book" class="nav-link" data-toggle="tab">
                            <i class="icon-plus2 mr-2"></i><?php echo e(__('Add New Book')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#book-categories" class="nav-link" data-toggle="tab">
                            <i class="icon-folder-open mr-2"></i><?php echo e(__('Categories')); ?> (<?php echo e(count($categories)); ?>)
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="all-books">
                    <table class="table datatable-button-html5-columns table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Book Title')); ?></th>
                            <th><?php echo e(__('ISBN')); ?></th>
                            <th><?php echo e(__('Author')); ?></th>
                            <th><?php echo e(__('Category')); ?></th>
                            <th><?php echo e(__('Location / Shelf')); ?></th>
                            <th><?php echo e(__('Copies (Total / Avail)')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th class="text-center"><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <div class="font-weight-semibold">
                                        <a href="<?php echo e(route('books.show', $b->id)); ?>"><?php echo e($b->name); ?></a>
                                    </div>
                                    <?php if($b->publisher): ?>
                                        <div class="text-muted font-size-xs"><?php echo e($b->publisher); ?> <?php if($b->publication_year): ?> (<?php echo e($b->publication_year); ?>) <?php endif; ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($b->isbn ?: '-'); ?></code></td>
                                <td><?php echo e($b->author ?: '-'); ?></td>
                                <td>
                                    <?php if($b->category): ?>
                                        <span class="badge badge-light border-left-primary badge-striped"><?php echo e($b->category->name); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($b->location ?: '-'); ?></td>
                                <td>
                                    <span class="font-weight-bold"><?php echo e($b->total_copies); ?></span> /
                                    <span class="font-weight-bold <?php echo e($b->available_copies > 0 ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e($b->available_copies); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($b->available_copies > 0): ?>
                                        <span class="badge badge-success"><?php echo e(__('Available')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><?php echo e(__('Out of Stock')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="list-icons">
                                        <div class="dropdown">
                                            <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                <i class="icon-menu9"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a href="<?php echo e(route('books.show', $b->id)); ?>" class="dropdown-item">
                                                    <i class="icon-eye"></i> <?php echo e(__('View Details')); ?>

                                                </a>
                                                <?php if(Qs::userIsTeamLibrary()): ?>
                                                    <a href="<?php echo e(route('books.edit', $b->id)); ?>" class="dropdown-item">
                                                        <i class="icon-pencil"></i> <?php echo e(__('Edit Book')); ?>

                                                    </a>
                                                    <?php if($b->available_copies > 0): ?>
                                                        <a href="<?php echo e(route('books.circulations')); ?>?book_id=<?php echo e($b->id); ?>" class="dropdown-item">
                                                            <i class="icon-reading"></i> <?php echo e(__('Issue This Book')); ?>

                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($b->issued_copies == 0): ?>
                                                        <a id="<?php echo e($b->id); ?>" onclick="confirmDelete(this.id)" href="#" class="dropdown-item text-danger">
                                                            <i class="icon-trash"></i> <?php echo e(__('Delete Book')); ?>

                                                        </a>
                                                        <form method="post" id="item-delete-<?php echo e($b->id); ?>" action="<?php echo e(route('books.destroy', $b->id)); ?>" class="hidden">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <?php if(Qs::userIsTeamLibrary()): ?>
                    <div class="tab-pane fade" id="new-book">
                        <form method="post" action="<?php echo e(route('books.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Book Title / Name')); ?> <span class="text-danger">*</span></label>
                                        <input name="name" value="<?php echo e(old('name')); ?>" required type="text" class="form-control" placeholder="<?php echo e(__('e.g. Compulsory English Grade 10')); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('ISBN')); ?></label>
                                        <input name="isbn" value="<?php echo e(old('isbn')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. 978-9937-12345-6')); ?>">
                                        <?php $__errorArgs = ['isbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Category')); ?></label>
                                        <select class="form-control select" name="category_id">
                                            <option value=""><?php echo e(__('Select Category')); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(old('category_id') == $cat->id ? 'selected' : ''); ?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Author')); ?></label>
                                        <input name="author" value="<?php echo e(old('author')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. Laxmi Prasad Devkota')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Publisher')); ?></label>
                                        <input name="publisher" value="<?php echo e(old('publisher')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. Sajha Prakashan')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Edition')); ?></label>
                                        <input name="edition" value="<?php echo e(old('edition')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. 3rd Edition')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Publication Year')); ?></label>
                                        <input name="publication_year" value="<?php echo e(old('publication_year')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. 2024')); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Class / Grade (Optional)')); ?></label>
                                        <select class="form-control select" name="my_class_id">
                                            <option value=""><?php echo e(__('General / All Classes')); ?></option>
                                            <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(old('my_class_id') == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Shelf / Rack Location')); ?></label>
                                        <input name="location" value="<?php echo e(old('location')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. Shelf A-3, Row 2')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Total Copies')); ?> <span class="text-danger">*</span></label>
                                        <input name="total_copies" value="<?php echo e(old('total_copies', 1)); ?>" min="1" required type="number" class="form-control">
                                        <?php $__errorArgs = ['total_copies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Language')); ?></label>
                                        <input name="language" value="<?php echo e(old('language', 'Nepali / English')); ?>" type="text" class="form-control" placeholder="<?php echo e(__('e.g. Nepali, English')); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Description / Synopsis')); ?></label>
                                        <textarea name="description" rows="3" class="form-control" placeholder="<?php echo e(__('Brief summary of the book content...')); ?>"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="font-weight-semibold"><?php echo e(__('Book Cover Image')); ?></label>
                                        <input name="cover_image" type="file" class="form-input-styled" data-fouc>
                                        <span class="form-text text-muted"><?php echo e(__('Accepted formats: jpg, png, jpeg. Max: 2MB')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="text-right">
                                <button type="submit" class="btn btn-primary font-weight-bold">
                                    <i class="icon-paperplane mr-2"></i><?php echo e(__('Save Book to Catalogue')); ?>

                                </button>
                            </div>
                        </form>
                    </div>

                    
                    <div class="tab-pane fade" id="book-categories">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(__('Category Name')); ?></th>
                                            <th><?php echo e(__('Slug')); ?></th>
                                            <th><?php echo e(__('Books Count')); ?></th>
                                            <th class="text-center"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td class="font-weight-semibold"><?php echo e($cat->name); ?></td>
                                                <td><code><?php echo e($cat->slug); ?></code></td>
                                                <td>
                                                    <span class="badge badge-primary"><?php echo e($cat->books_count ?? count($cat->books ?? [])); ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <?php if(($cat->books_count ?? count($cat->books ?? [])) == 0): ?>
                                                        <a id="cat-<?php echo e($cat->id); ?>" onclick="confirmDelete(this.id)" href="#" class="btn btn-sm btn-outline-danger">
                                                            <i class="icon-trash"></i>
                                                        </a>
                                                        <form method="post" id="item-delete-cat-<?php echo e($cat->id); ?>" action="<?php echo e(route('books.categories.destroy', $cat->id)); ?>" class="hidden">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                        </form>
                                                    <?php else: ?>
                                                        <span class="text-muted font-size-xs" title="<?php echo e(__('Has associated books')); ?>"><i class="icon-lock2"></i> In use</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="col-md-5">
                                <div class="card card-body bg-light border-primary">
                                    <h6 class="font-weight-semibold text-primary"><i class="icon-plus-circle2 mr-2"></i><?php echo e(__('Add New Category')); ?></h6>
                                    <form method="post" action="<?php echo e(route('books.categories.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="font-weight-semibold"><?php echo e(__('Category Name')); ?> <span class="text-danger">*</span></label>
                                            <input name="name" required type="text" class="form-control" placeholder="<?php echo e(__('e.g. Science & Technology')); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="font-weight-semibold"><?php echo e(__('Description')); ?></label>
                                            <textarea name="description" rows="2" class="form-control" placeholder="<?php echo e(__('Optional category notes...')); ?>"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-block">
                                            <i class="icon-check mr-2"></i><?php echo e(__('Create Category')); ?>

                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\index.blade.php ENDPATH**/ ?>