<?php $__env->startSection('page_title', __('Class-wise Attendance Comparison Report (BS)')); ?>
<?php $__env->startSection('content'); ?>

    <?php if(isset($has_assignment) && !$has_assignment): ?>
        <div class="alert alert-warning border-0">
            <h5 class="alert-heading font-weight-semibold mb-1"><i class="icon-warning22 mr-1"></i> <?php echo e(__('No Class / Section Assigned')); ?></h5>
            <?php echo e(__('You are not currently assigned as a class teacher to any class or section. Student attendance comparison reports cannot be accessed until an administrator assigns you to a section.')); ?>

        </div>
    <?php else: ?>
        <div class="card d-print-none">
            <div class="card-header header-elements-inline">
                <h6 class="card-title font-weight-bold"><?php echo e(__('Class-wise Attendance Comparison Report')); ?></h6>
                <?php echo Qs::getPanelOptions(); ?>

            </div>

            <div class="card-body">
                <form method="get" action="<?php echo e(route('attendance.class_report')); ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <label class="font-weight-bold"><?php echo e(__('Select Attendance Date (BS)')); ?>: <span class="text-danger">*</span></label>
                            <input type="text" name="attendance_date_bs" value="<?php echo e($selected_date); ?>" required class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                            <?php if(isset($date_info) && $date_info['ad_date']): ?>
                                <span class="form-text text-muted"><?php echo e($date_info['ad_date']); ?> AD</span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-3 pt-md-4">
                            <button type="submit" class="btn btn-primary btn-block"><i class="icon-filter3 mr-1"></i> <?php echo e(__('Generate Report')); ?></button>
                        </div>
                        <div class="col-md-3 pt-md-4">
                            <button type="button" class="btn btn-outline-secondary btn-block" onclick="window.print()"><i class="icon-printer mr-1"></i> <?php echo e(__('Print Report')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if(isset($date_info) && $date_info['warning']): ?>
            <div class="alert alert-<?php echo e($date_info['is_holiday'] ? 'danger' : 'warning'); ?> border-0 alert-dismissible">
                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                <span class="font-weight-semibold"><i class="icon-warning22 mr-1"></i> <?php echo e($date_info['warning']); ?></span>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header header-elements-inline">
                <h6 class="card-title font-weight-bold">
                    <?php echo e(__('Attendance Overview by Class')); ?> - [<?php echo e($selected_date); ?> BS]
                </h6>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('Class')); ?></th>
                            <th><?php echo e(__('Enrolled')); ?></th>
                            <th><?php echo e(__('Recorded')); ?></th>
                            <th><?php echo e(__('Present')); ?></th>
                            <th><?php echo e(__('Absent')); ?></th>
                            <th><?php echo e(__('Late')); ?></th>
                            <th><?php echo e(__('Leave')); ?></th>
                            <th><?php echo e(__('Attendance %')); ?></th>
                            <th class="d-print-none"><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $totEnrolled = 0;
                            $totRecorded = 0;
                            $totPresent = 0;
                            $totAbsent = 0;
                        ?>
                        <?php $__currentLoopData = $classes_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totEnrolled += $cr['total_students'];
                                $totRecorded += $cr['recorded_attendance'];
                                $totPresent += $cr['present'];
                                $totAbsent += $cr['absent'];
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-bold"><?php echo e($cr['class']->name); ?></td>
                                <td><?php echo e($cr['total_students']); ?></td>
                                <td>
                                    <?php if($cr['recorded_attendance'] > 0): ?>
                                        <span class="badge badge-success"><?php echo e($cr['recorded_attendance']); ?> / <?php echo e($cr['total_students']); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><?php echo e(__('Not Recorded')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-success font-weight-semibold"><?php echo e($cr['present']); ?></td>
                                <td class="text-danger font-weight-semibold"><?php echo e($cr['absent']); ?></td>
                                <td class="text-warning font-weight-semibold"><?php echo e($cr['late']); ?></td>
                                <td class="text-info font-weight-semibold"><?php echo e($cr['leave']); ?></td>
                                <td>
                                    <?php if($cr['recorded_attendance'] > 0): ?>
                                        <div class="d-flex align-items-center">
                                            <div class="progress w-100 mr-2" style="height: 12px;">
                                                <div class="progress-bar <?php echo e($cr['percentage'] >= 75 ? 'bg-success' : ($cr['percentage'] >= 60 ? 'bg-warning' : 'bg-danger')); ?>" style="width: <?php echo e($cr['percentage']); ?>%;"></div>
                                            </div>
                                            <span class="font-weight-bold font-size-sm"><?php echo e($cr['percentage']); ?>%</span>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="d-print-none">
                                    <a href="<?php echo e(route('attendance.index', ['my_class_id' => $cr['class']->id, 'attendance_date_bs' => $selected_date])); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('View / Record')); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot class="bg-light font-weight-bold">
                        <tr>
                            <td colspan="2"><?php echo e(__('Total School Summary')); ?></td>
                            <td><?php echo e($totEnrolled); ?></td>
                            <td><?php echo e($totRecorded); ?></td>
                            <td class="text-success"><?php echo e($totPresent); ?></td>
                            <td class="text-danger"><?php echo e($totAbsent); ?></td>
                            <td colspan="2"></td>
                            <td>
                                <?php
                                    $overallPct = $totRecorded > 0 ? round(($totPresent / $totRecorded) * 100, 1) : 0.0;
                                ?>
                                <span><?php echo e($overallPct); ?>%</span>
                            </td>
                            <td class="d-print-none"></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\attendance\class_report.blade.php ENDPATH**/ ?>