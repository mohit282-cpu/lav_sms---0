<?php $__env->startSection('page_title', __('Student Daily Attendance (BS)')); ?>
<?php $__env->startSection('content'); ?>

    <?php if(isset($has_assignment) && !$has_assignment): ?>
        <div class="alert alert-warning border-0">
            <h5 class="alert-heading font-weight-semibold mb-1"><i class="icon-warning22 mr-1"></i> <?php echo e(__('No Class / Section Assigned')); ?></h5>
            <?php echo e(__('You are not currently assigned as a class teacher to any class or section. Student attendance cannot be accessed or recorded until an administrator assigns you to a section.')); ?>

        </div>
    <?php else: ?>
        
        <div id="pwa-attendance-offline-widget" class="card border-left-3 border-left-warning mb-3" style="display: none;">
            <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                <h6 class="font-weight-bold mb-0 text-warning-800">
                    <i class="icon-cloud-check mr-2"></i> <?php echo e(__('Offline Attendance Batches')); ?>

                    <span id="pwa-pending-count-badge" class="badge badge-warning ml-2">0</span>
                </h6>
                <div>
                    <button type="button" class="btn btn-sm btn-primary" id="pwa-btn-sync-all" onclick="PwaAttendanceUI.syncAll()">
                        <i class="icon-sync mr-1"></i> <?php echo e(__('Sync All to Server')); ?>

                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="p-2 bg-light border-bottom font-size-xs text-muted">
                    <i class="icon-info22 mr-1"></i> <?php echo e(__('Notice: Offline attendance batches are stored locally and are NOT yet confirmed by the server. Connect to the internet and click "Sync" to finalize.')); ?>

                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr class="table-active">
                                <th><?php echo e(__('Date (BS)')); ?></th>
                                <th><?php echo e(__('Class & Section')); ?></th>
                                <th><?php echo e(__('Records')); ?></th>
                                <th><?php echo e(__('Sync Status')); ?></th>
                                <th class="text-right"><?php echo e(__('Actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody id="pwa-drafts-tbody">
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header header-elements-inline">
                <h6 class="card-title font-weight-bold"><?php echo e(__('Student Daily Attendance (Bikram Sambat)')); ?></h6>
                <?php echo Qs::getPanelOptions(); ?>

            </div>

            <div class="card-body">
                
                <form method="get" action="<?php echo e(route('attendance.index')); ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="my_class_id" class="font-weight-bold"><?php echo e(__('Select Class')); ?>: <span class="text-danger">*</span></label>
                                <select onchange="getAttendanceSections(this.value)" required id="my_class_id" name="my_class_id" class="form-control select">
                                    <option value=""><?php echo e(__('Select Class')); ?></option>
                                    <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(($selected_class == $c->id) ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="section_id" class="font-weight-bold"><?php echo e(__('Select Section')); ?>:</label>
                                <select id="section_id" name="section_id" class="form-control select">
                                    <?php if(Auth::user()->user_type !== 'teacher' || count($sections) > 1): ?>
                                        <option value=""><?php echo e(__('All Sections')); ?></option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(($selected_section == $s->id) ? 'selected' : ''); ?> value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="attendance_date_bs" class="font-weight-bold"><?php echo e(__('Attendance Date (BS)')); ?>: <span class="text-danger">*</span></label>
                                <input type="text" id="attendance_date_bs" name="attendance_date_bs" value="<?php echo e($selected_date); ?>" required class="form-control nepali-date" placeholder="YYYY-MM-DD (BS)">
                                <?php if(isset($date_info) && $date_info['ad_date']): ?>
                                    <span class="form-text text-muted"><?php echo e($date_info['ad_date']); ?> AD</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group pt-md-4">
                                <button type="submit" class="btn btn-primary btn-block"><i class="icon-filter3 mr-1"></i> <?php echo e(__('Filter / Load Students')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if($selected_class): ?>
            
            <?php if(isset($date_info) && $date_info['warning']): ?>
                <div class="alert alert-<?php echo e($date_info['is_holiday'] ? 'danger' : 'warning'); ?> border-0 alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                    <span class="font-weight-semibold"><i class="icon-warning22 mr-1"></i> <?php echo e($date_info['warning']); ?></span>
                </div>
            <?php endif; ?>

            <?php if($is_already_recorded): ?>
                <div class="alert alert-info border-0 alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                    <i class="icon-info22 mr-1"></i> <?php echo e(__('Attendance has already been recorded for this date. Modifying the entries below will update the records and log an audit trail.')); ?>

                </div>
            <?php endif; ?>

            <?php if(!$can_manage): ?>
                <div class="alert alert-danger border-0">
                    <i class="icon-blocked mr-1"></i> <?php echo e(__('Read-Only: You are not assigned as the class teacher for this class or section. Attendance cannot be submitted.')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title font-weight-bold">
                        <?php echo e(__('Students List')); ?> (<?php echo e(count($students)); ?>)
                        <span class="text-muted ml-2 font-size-sm">[<?php echo e($selected_date); ?> BS]</span>
                    </h6>
                    <div class="header-elements">
                        <?php if($can_manage && count($students) > 0): ?>
                            <button type="button" class="btn btn-sm btn-outline-success mr-2" onclick="markAllStatus('present')"><i class="icon-checkmark4 mr-1"></i> <?php echo e(__('Mark All Present')); ?></button>
                            <button type="button" class="btn btn-sm btn-outline-danger mr-2" onclick="markAllStatus('absent')"><i class="icon-cross2 mr-1"></i> <?php echo e(__('Mark All Absent')); ?></button>
                        <?php endif; ?>
                        <a href="<?php echo e(route('attendance.monthly', ['my_class_id' => $selected_class, 'section_id' => $selected_section])); ?>" class="btn btn-sm btn-info"><i class="icon-calendar52 mr-1"></i> <?php echo e(__('Monthly Sheet')); ?></a>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(count($students) > 0): ?>
                        <form method="post" action="<?php echo e(route('attendance.store')); ?>" id="attendance-entry-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="my_class_id" value="<?php echo e($selected_class); ?>">
                            <input type="hidden" name="section_id" value="<?php echo e($selected_section); ?>">
                            <input type="hidden" name="attendance_date_bs" value="<?php echo e($selected_date); ?>">

                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('Adm No')); ?></th>
                                        <th><?php echo e(__('Photo')); ?></th>
                                        <th><?php echo e(__('Student Name')); ?></th>
                                        <th><?php echo e(__('Status')); ?></th>
                                        <th><?php echo e(__('Remarks / Reason')); ?></th>
                                        <th><?php echo e(__('Action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $existing = $existing_records->get($sr->id);
                                            $curStatus = $existing ? $existing->status : 'present';
                                            $curRemarks = $existing ? $existing->remarks : '';
                                        ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="font-weight-semibold"><?php echo e($sr->adm_no); ?></td>
                                            <td><img class="rounded-circle" style="height: 38px; width: 38px;" src="<?php echo e($sr->user->photo); ?>" alt="img"></td>
                                            <td>
                                                <span class="font-weight-bold"><?php echo e($sr->user->name); ?></span>
                                                <br>
                                                <span class="text-muted font-size-sm"><?php echo e($sr->my_class->name); ?> <?php echo e($sr->section ? '- '.$sr->section->name : ''); ?></span>
                                            </td>
                                            <td>
                                                <?php if($can_manage): ?>
                                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                        <label class="btn btn-sm btn-outline-success <?php echo e($curStatus === 'present' ? 'active' : ''); ?>">
                                                            <input type="radio" name="students[<?php echo e($sr->id); ?>][status]" value="present" class="att-status" <?php echo e($curStatus === 'present' ? 'checked' : ''); ?>> <?php echo e(__('Present')); ?>

                                                        </label>
                                                        <label class="btn btn-sm btn-outline-danger <?php echo e($curStatus === 'absent' ? 'active' : ''); ?>">
                                                            <input type="radio" name="students[<?php echo e($sr->id); ?>][status]" value="absent" class="att-status" <?php echo e($curStatus === 'absent' ? 'checked' : ''); ?>> <?php echo e(__('Absent')); ?>

                                                        </label>
                                                        <label class="btn btn-sm btn-outline-warning <?php echo e($curStatus === 'late' ? 'active' : ''); ?>">
                                                            <input type="radio" name="students[<?php echo e($sr->id); ?>][status]" value="late" class="att-status" <?php echo e($curStatus === 'late' ? 'checked' : ''); ?>> <?php echo e(__('Late')); ?>

                                                        </label>
                                                        <label class="btn btn-sm btn-outline-info <?php echo e($curStatus === 'leave' ? 'active' : ''); ?>">
                                                            <input type="radio" name="students[<?php echo e($sr->id); ?>][status]" value="leave" class="att-status" <?php echo e($curStatus === 'leave' ? 'checked' : ''); ?>> <?php echo e(__('Leave')); ?>

                                                        </label>
                                                        <label class="btn btn-sm btn-outline-secondary <?php echo e($curStatus === 'half_day' ? 'active' : ''); ?>">
                                                            <input type="radio" name="students[<?php echo e($sr->id); ?>][status]" value="half_day" class="att-status" <?php echo e($curStatus === 'half_day' ? 'checked' : ''); ?>> <?php echo e(__('Half Day')); ?>

                                                        </label>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="badge badge-<?php echo e($curStatus === 'present' ? 'success' : ($curStatus === 'absent' ? 'danger' : 'warning')); ?> p-2"><?php echo e(ucfirst($curStatus)); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($can_manage): ?>
                                                    <input type="text" name="students[<?php echo e($sr->id); ?>][remarks]" value="<?php echo e(old('students.'.$sr->id.'.remarks', $curRemarks)); ?>" class="form-control form-control-sm" placeholder="<?php echo e(__('Optional remarks (e.g. sick, doctor visit)')); ?>">
                                                <?php else: ?>
                                                    <span><?php echo e($curRemarks ?: '-'); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('attendance.student_history', $sr->id)); ?>" target="_blank" class="btn btn-sm btn-outline-primary" title="<?php echo e(__('View Attendance History')); ?>"><i class="icon-history"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($can_manage): ?>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary btn-lg" onclick="return confirm('<?php echo e(__('Are you sure you want to save attendance for this date?')); ?>')">
                                        <i class="icon-paperplane mr-2"></i> <?php echo e(__('Save Attendance')); ?>

                                    </button>
                                </div>
                            <?php endif; ?>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-warning border-0">
                            <i class="icon-info22 mr-1"></i> <?php echo e(__('No students found in this class or section.')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <script>
        function markAllStatus(status) {
            var radios = document.querySelectorAll('.att-status[value="' + status + '"]');
            radios.forEach(function(radio) {
                radio.checked = true;
                var parentGroup = radio.closest('.btn-group');
                if (parentGroup) {
                    var labels = parentGroup.querySelectorAll('label');
                    labels.forEach(function(l) { l.classList.remove('active'); });
                    radio.parentElement.classList.add('active');
                }
            });
        }

        function getAttendanceSections(classId) {
            if (!classId) return;
            var url = '<?php echo e(route('attendance.get_sections', ':id')); ?>'.replace(':id', classId);
            var sectionSelect = $('#section_id');
            $.ajax({
                dataType: 'json',
                url: url,
                success: function(resp) {
                    sectionSelect.empty();
                    if (resp.length > 1 || <?php echo e(Auth::user()->user_type !== 'teacher' ? 'true' : 'false'); ?>) {
                        sectionSelect.append($('<option>', { value: '', text: '<?php echo e(__('All Sections')); ?>' }));
                    }
                    $.each(resp, function(i, s) {
                        sectionSelect.append($('<option>', { value: s.id, text: s.name }));
                    });
                }
            });
        }

        // Offline Attendance Interception
        var attForm = document.getElementById('attendance-entry-form');
        if (attForm) {
            attForm.addEventListener('submit', function (e) {
                if (!navigator.onLine) {
                    e.preventDefault();

                    var form = this;
                    var classId = form.querySelector('input[name="my_class_id"]').value;
                    var sectionInput = form.querySelector('input[name="section_id"]');
                    var sectionId = sectionInput ? sectionInput.value : null;
                    var dateBs = form.querySelector('input[name="attendance_date_bs"]').value;

                    var studentsData = {};
                    var checkedRadios = form.querySelectorAll('.att-status:checked');
                    checkedRadios.forEach(function (radio) {
                        var match = radio.name.match(/students\[(\d+)\]\[status\]/);
                        if (match) {
                            var stId = match[1];
                            var remarksInput = form.querySelector('input[name="students[' + stId + '][remarks]"]');
                            studentsData[stId] = {
                                status: radio.value,
                                remarks: remarksInput ? remarksInput.value : ''
                            };
                        }
                    });

                    if (Object.keys(studentsData).length === 0) {
                        alert('<?php echo e(__("Please select attendance status for at least one student.")); ?>');
                        return;
                    }

                    if (!window.PwaAttendance) {
                        alert('<?php echo e(__("PWA offline storage module is not loaded.")); ?>');
                        return;
                    }

                    window.PwaAttendance.saveDraft({
                        my_class_id: classId,
                        class_name: '<?php echo e($selected_class ? ($my_classes->where("id", $selected_class)->first()->name ?? "") : ""); ?>',
                        section_id: sectionId,
                        section_name: '<?php echo e($selected_section ? ($sections->where("id", $selected_section)->first()->name ?? "") : ""); ?>',
                        attendance_date_bs: dateBs,
                        students: studentsData
                    }, function (err, saved) {
                        if (err) {
                            alert('<?php echo e(__("Failed to save offline draft: ")); ?>' + err.message);
                            return;
                        }

                        if (window.swal) {
                            swal({
                                title: '<?php echo e(__("Offline Draft Stored Locally!")); ?>',
                                text: '<?php echo e(__("Attendance has NOT yet been confirmed by the server. Please reconnect to the internet and click \"Sync All to Server\" to commit it to the school database.")); ?>',
                                type: 'warning',
                                confirmButtonClass: 'btn btn-primary',
                                confirmButtonText: '<?php echo e(__("Acknowledge")); ?>'
                            });
                        } else {
                            alert('<?php echo e(__("Offline Draft Stored Locally! Attendance is NOT yet saved to the server. Please click Sync when back online.")); ?>');
                        }

                        if (window.PwaAttendanceUI) {
                            window.PwaAttendanceUI.refreshWidget();
                        }
                    });
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views/pages/support_team/attendance/index.blade.php ENDPATH**/ ?>