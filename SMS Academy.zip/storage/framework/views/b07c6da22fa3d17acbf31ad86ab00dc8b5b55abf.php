<?php $__env->startSection('page_title', __('Edit Book: :name', ['name' => $book->name])); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title font-weight-semibold"><i class="icon-pencil mr-2"></i><?php echo e(__('Edit Book Information')); ?></h6>
            <div class="header-elements">
                <a href="<?php echo e(route('books.index')); ?>" class="btn btn-sm btn-outline-dark">
                    <i class="icon-arrow-left7 mr-1"></i> <?php echo e(__('Back to Inventory')); ?>

                </a>
            </div>
        </div>

        <div class="card-body">
            <form method="post" action="<?php echo e(route('books.update', $book->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Book Title / Name')); ?> <span class="text-danger">*</span></label>
                            <input name="name" value="<?php echo e(old('name', $book->name)); ?>" required type="text" class="form-control">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('ISBN')); ?></label>
                            <input name="isbn" value="<?php echo e(old('isbn', $book->isbn)); ?>" type="text" class="form-control">
                            <?php $__errorArgs = ['isbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Category')); ?></label>
                            <select class="form-control select" name="category_id">
                                <option value=""><?php echo e(__('Select Category')); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('category_id', $book->category_id) == $cat->id ? 'selected' : ''); ?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Author')); ?></label>
                            <input name="author" value="<?php echo e(old('author', $book->author)); ?>" type="text" class="form-control">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Publisher')); ?></label>
                            <input name="publisher" value="<?php echo e(old('publisher', $book->publisher)); ?>" type="text" class="form-control">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Edition')); ?></label>
                            <input name="edition" value="<?php echo e(old('edition', $book->edition)); ?>" type="text" class="form-control">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Publication Year')); ?></label>
                            <input name="publication_year" value="<?php echo e(old('publication_year', $book->publication_year)); ?>" type="text" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Class / Grade (Optional)')); ?></label>
                            <select class="form-control select" name="my_class_id">
                                <option value=""><?php echo e(__('General / All Classes')); ?></option>
                                <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('my_class_id', $book->my_class_id) == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Shelf / Rack Location')); ?></label>
                            <input name="location" value="<?php echo e(old('location', $book->location)); ?>" type="text" class="form-control">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Total Copies')); ?> <span class="text-danger">*</span></label>
                            <input name="total_copies" value="<?php echo e(old('total_copies', $book->total_copies)); ?>" min="<?php echo e($book->issued_copies); ?>" required type="number" class="form-control">
                            <span class="form-text text-muted font-size-xs"><?php echo e(__('Cannot be less than issued copies (:count)', ['count' => $book->issued_copies])); ?></span>
                            <?php $__errorArgs = ['total_copies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger font-size-xs"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Language')); ?></label>
                            <input name="language" value="<?php echo e(old('language', $book->language)); ?>" type="text" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Description / Synopsis')); ?></label>
                            <textarea name="description" rows="3" class="form-control"><?php echo e(old('description', $book->description)); ?></textarea>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-weight-semibold"><?php echo e(__('Book Cover Image')); ?></label>
                            <?php if($book->cover_image): ?>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset('storage/' . $book->cover_image)); ?>" height="60" class="rounded border">
                                </div>
                            <?php endif; ?>
                            <input name="cover_image" type="file" class="form-input-styled" data-fouc>
                            <span class="form-text text-muted"><?php echo e(__('Accepted: jpg, png, jpeg. Max: 2MB')); ?></span>
                        </div>
                    </div>
                </div>

                <div class="text-right">
                    <a href="<?php echo e(route('books.index')); ?>" class="btn btn-light mr-2"><?php echo e(__('Cancel')); ?></a>
                    <button type="submit" class="btn btn-primary font-weight-bold">
                        <i class="icon-check mr-2"></i><?php echo e(__('Update Book')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\books\edit.blade.php ENDPATH**/ ?>