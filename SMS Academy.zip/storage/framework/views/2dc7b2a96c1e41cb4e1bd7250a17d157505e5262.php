<div class="navbar navbar-expand-lg navbar-light">
    <div class="text-center d-lg-none w-100">
        <button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse" data-target="#navbar-footer">
            <i class="icon-unfold mr-2"></i>
            More Links
        </button>
    </div>

    <div class="navbar-collapse collapse" id="navbar-footer">
					<span class="navbar-text">
						&copy; <?php echo e(date('Y')); ?>. <a href="#"><?php echo e(Qs::getSystemName()); ?></a> by <a href="#" >SMS Academy</a>
					</span>

        <ul class="navbar-nav ml-lg-auto">
            <li class="nav-item"><a href="<?php echo e(route('privacy_policy')); ?>" class="navbar-nav-link" target="_blank"><i class="icon-lifebuoy mr-2"></i> Privacy Policy</a></li>
            <li class="nav-item"><a href="<?php echo e(route('terms_of_use')); ?>" class="navbar-nav-link" target="_blank"><i class="icon-file-text2 mr-2"></i> Terms of Use </a></li>

        </ul>
    </div>
</div>


<script>
    window.PWA_SW_PATH = "<?php echo e(route('pwa.sw')); ?>";
    window.PWA_USER_ID = null;
    window.PWA_ICON_PATH = "<?php echo e(asset('assets/images/icons/icon-192x192.png')); ?>";
    window.PWA_APP_NAME = "<?php echo e(Qs::getSystemName()); ?>";
    window.PWA_I18N_UPDATE = "<?php echo e(__('A new version of the school portal is ready.')); ?>";
    window.PWA_I18N_UPDATE_BTN = "<?php echo e(__('Update Now')); ?>";
    window.PWA_I18N_INSTALL_DESC = "<?php echo e(__('Install school portal for quick and reliable access')); ?>";
    window.PWA_I18N_INSTALL_BTN = "<?php echo e(__('Install App')); ?>";
    window.PWA_I18N_ONLINE = "<?php echo e(__('Connection Restored')); ?>";
    window.PWA_I18N_OFFLINE = "<?php echo e(__('Offline Mode - Live actions require connection')); ?>";
</script>
<script src="<?php echo e(asset('assets/js/pwa.js')); ?>"></script>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\partials\login\footer.blade.php ENDPATH**/ ?>