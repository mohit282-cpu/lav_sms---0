<table class="table table-bordered table-responsive text-center">
    <thead>
    <tr>
        <th><?php echo e(__('SN')); ?></th>
        <th><?php echo e(__('Subject')); ?></th>
        <th><?php echo e(__('Credit Hour')); ?></th>
        <th><?php echo e(__('Theory')); ?></th>
        <th><?php echo e(__('Practical')); ?></th>
        <th><?php echo e(__('Total')); ?></th>
        <th><?php echo e(__('Grade Point')); ?></th>
        <th><?php echo e(__('Letter Grade')); ?></th>
        <th><?php echo e(__('Remarks')); ?></th>
    </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $mk = $marks->where('subject_id', $sub->id)->where('exam_id', $ex->id)->first();
        ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td class="text-left font-weight-semibold"><?php echo e($sub->name); ?></td>
            <td><?php echo e(number_format($sub->credit_hour ?: 4.0, 2)); ?></td>
            <td>
                <?php if($mk): ?>
                    <?php if($mk->is_absent): ?> <span class="badge badge-danger">ABS</span>
                    <?php elseif($mk->is_exempt): ?> <span class="badge badge-warning">EXM</span>
                    <?php else: ?> <?php echo e($mk->theory_mark !== null ? $mk->theory_mark : ($mk->exm ?? '-')); ?>

                    <?php endif; ?>
                <?php else: ?> -
                <?php endif; ?>
            </td>
            <td>
                <?php if($sub->has_practical): ?>
                    <?php if($mk): ?>
                        <?php if($mk->is_absent): ?> <span class="badge badge-danger">ABS</span>
                        <?php elseif($mk->is_exempt): ?> <span class="badge badge-warning">EXM</span>
                        <?php else: ?> <?php echo e($mk->practical_mark !== null ? $mk->practical_mark : ($mk->t1 ?? '-')); ?>

                        <?php endif; ?>
                    <?php else: ?> -
                    <?php endif; ?>
                <?php else: ?>
                    <span class="text-muted">-</span>
                <?php endif; ?>
            </td>
            <td class="font-weight-bold">
                <?php if($mk): ?>
                    <?php if($mk->is_absent): ?> <span class="badge badge-danger">ABS</span>
                    <?php elseif($mk->is_exempt): ?> <span class="badge badge-warning">EXM</span>
                    <?php else: ?> <?php echo e($mk->total_mark !== null ? $mk->total_mark : ($mk->{'tex'.$ex->term} ?? '-')); ?>

                    <?php endif; ?>
                <?php else: ?> -
                <?php endif; ?>
            </td>
            <td class="font-weight-bold" style="color: purple;">
                <?php echo e($mk && $mk->gpa_point !== null ? number_format($mk->gpa_point, 2) : '-'); ?>

            </td>
            <td>
                <?php if($mk && $mk->grade_name): ?>
                    <span class="badge <?php echo e(in_array($mk->grade_name, ['A+', 'A', 'B+']) ? 'badge-success' : (in_array($mk->grade_name, ['B', 'C+', 'C', 'D']) ? 'badge-info' : 'badge-danger')); ?>">
                        <?php echo e($mk->grade_name); ?>

                    </span>
                <?php elseif($mk && $mk->grade): ?>
                    <span class="badge badge-secondary"><?php echo e($mk->grade->name); ?></span>
                <?php else: ?> -
                <?php endif; ?>
            </td>
            <td><?php echo e($mk->remarks ?? ($mk && $mk->grade ? $mk->grade->remark : '-')); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr class="font-weight-bold" style="background-color: #f8f9fa;">
        <td colspan="3" class="text-left"><strong><?php echo e(__('Total Marks')); ?>:</strong> <?php echo e($exr->total ?: '-'); ?></td>
        <td colspan="2"><strong><?php echo e(__('Percentage')); ?>:</strong> <?php echo e($exr->ave ? number_format($exr->ave, 2).'%' : '-'); ?></td>
        <td colspan="2" style="color: purple;"><strong><?php echo e(__('GPA')); ?>:</strong> <?php echo e($exr->gpa !== null ? number_format($exr->gpa, 2) : '-'); ?></td>
        <td><strong><?php echo e(__('Grade')); ?>:</strong> <?php echo e($exr->grade ?: '-'); ?></td>
        <td style="color: <?php echo e(($exr->result_status ?? '') === 'PASS' ? '#28a745' : (($exr->result_status ?? '') === 'FAIL' ? '#dc3545' : '#6c757d')); ?>">
            <strong><?php echo e(__('Result')); ?>:</strong> <?php echo e($exr->result_status ?: '-'); ?>

        </td>
    </tr>
    </tbody>
</table>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\marks\show\sheet.blade.php ENDPATH**/ ?>