<form class="ajax-update" action="<?php echo e(route('marks.update', [$exam_id, $my_class_id, $section_id, $subject_id])); ?>" method="post">
    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
    <div class="table-responsive">
        <table class="table table-striped table-bordered text-center">
            <thead>
            <tr class="bg-light">
                <th style="width: 5%;">#</th>
                <th style="text-align: left; width: 22%;"><?php echo e(__('Student Name')); ?></th>
                <th style="width: 15%;"><?php echo e(__('Roll / Adm No')); ?></th>
                <th><?php echo e(__('Theory')); ?> (Max <?php echo e($m->subject->theory_max ?? 75); ?>)</th>
                <?php if($m->subject->has_practical ?? true): ?>
                    <th><?php echo e(__('Practical')); ?> (Max <?php echo e($m->subject->practical_max ?? 25); ?>)</th>
                <?php endif; ?>
                <th><?php echo e(__('Total')); ?></th>
                <th><?php echo e(__('Grade / GPA')); ?></th>
                <th><?php echo e(__('Absent')); ?></th>
                <th><?php echo e(__('Exempt')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $marks->sortBy('user.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td style="text-align: left;">
                        <span class="font-weight-semibold"><?php echo e($mk->user->name); ?></span>
                    </td>
                    <td><?php echo e($mk->user->student_record->adm_no ?? '-'); ?></td>

                    
                    <td>
                        <input title="<?php echo e(__('Theory Marks')); ?>"
                               min="0"
                               max="<?php echo e($m->subject->theory_max ?? 100); ?>"
                               step="0.5"
                               class="form-control text-center theory-input"
                               name="theory_<?php echo e($mk->id); ?>"
                               value="<?php echo e($mk->theory_mark ?? $mk->exm); ?>"
                               type="number"
                               style="max-width: 110px; margin: 0 auto;">
                    </td>

                    
                    <?php if($m->subject->has_practical ?? true): ?>
                        <td>
                            <input title="<?php echo e(__('Practical Marks')); ?>"
                                   min="0"
                                   max="<?php echo e($m->subject->practical_max ?? 25); ?>"
                                   step="0.5"
                                   class="form-control text-center practical-input"
                                   name="practical_<?php echo e($mk->id); ?>"
                                   value="<?php echo e($mk->practical_mark ?? $mk->t1); ?>"
                                   type="number"
                                   style="max-width: 110px; margin: 0 auto;">
                        </td>
                    <?php endif; ?>

                    
                    <td>
                        <span class="font-weight-bold total-display text-primary">
                            <?php echo e($mk->is_absent ? 'ABS' : ($mk->is_exempt ? 'EXM' : ($mk->total_mark ?? ($mk->tca + $mk->exm)))); ?>

                        </span>
                    </td>

                    
                    <td>
                        <span class="badge <?php echo e(($mk->grade_name === 'NG' || $mk->is_absent) ? 'badge-danger' : 'badge-success'); ?> p-1 font-weight-bold">
                            <?php echo e($mk->grade_name ?? ($mk->grade ? $mk->grade->name : '-')); ?>

                            <?php if($mk->gpa_point !== null): ?>
                                (<?php echo e(number_format($mk->gpa_point, 2)); ?>)
                            <?php endif; ?>
                        </span>
                    </td>

                    
                    <td>
                        <div class="form-check">
                            <label class="form-check-label">
                                <input type="checkbox" name="absent_<?php echo e($mk->id); ?>" value="1" <?php echo e($mk->is_absent ? 'checked' : ''); ?> class="form-check-input status-absent">
                            </label>
                        </div>
                    </td>

                    
                    <td>
                        <div class="form-check">
                            <label class="form-check-label">
                                <input type="checkbox" name="exempt_<?php echo e($mk->id); ?>" value="1" <?php echo e($mk->is_exempt ? 'checked' : ''); ?> class="form-check-input status-exempt">
                            </label>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="text-right mt-3">
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="icon-floppy-disk mr-2"></i> <?php echo e(__('Save & Compute Nepal Grades')); ?>

        </button>
    </div>
</form>
<?php /**PATH Z:\Xampp\htdocs\lav_sms - 0\resources\views\pages\support_team\marks\edit.blade.php ENDPATH**/ ?>